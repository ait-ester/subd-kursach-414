import os
import sys


def fix_qt_plugins():
    """Исправление пути к плагинам Qt для Windows"""
    if sys.platform == 'win32':
        # Пробуем несколько возможных путей
        possible_paths = [
            # Путь в виртуальной среде
            os.path.join(os.path.dirname(sys.executable), 'Lib', 'site-packages', 'PyQt5', 'Qt5', 'plugins'),
            # Путь в системном Python
            os.path.join(sys.prefix, 'Lib', 'site-packages', 'PyQt5', 'Qt5', 'plugins'),
            # Путь в пользовательской установке
            os.path.join(os.environ.get('APPDATA', ''), 'Python', 'Python311', 'site-packages', 'PyQt5', 'Qt5',
                         'plugins'),
        ]

        for path in possible_paths:
            if os.path.exists(path):
                os.environ['QT_PLUGIN_PATH'] = path
                print(f"Установлен путь к плагинам Qt: {path}")
                return True

        print("Не удалось найти плагины Qt")
        return False
    return True


if __name__ == "__main__":
    fix_qt_plugins()
    # Теперь запускаем ваше приложение
    from main import main

    main()