"""
Стили для приложения
"""


def get_stylesheet():
    """Возвращает строку со стилями CSS для приложения"""
    return """
    QMainWindow {
        background-color: #f5f5f5;
    }

    QWidget {
        font-family: "Segoe UI", Arial, sans-serif;
        font-size: 10pt;
    }

    QTabWidget::pane {
        border: 1px solid #ccc;
        background-color: white;
    }

    QTabBar::tab {
        background-color: #e0e0e0;
        padding: 8px 16px;
        margin-right: 2px;
        border: 1px solid #ccc;
        border-bottom: none;
        border-top-left-radius: 4px;
        border-top-right-radius: 4px;
    }

    QTabBar::tab:selected {
        background-color: white;
        border-bottom: 2px solid #007bff;
        font-weight: bold;
    }

    QTabBar::tab:hover:!selected {
        background-color: #f0f0f0;
    }

    QPushButton {
        background-color: #007bff;
        color: white;
        border: none;
        padding: 8px 16px;
        border-radius: 4px;
        font-weight: bold;
    }

    QPushButton:hover {
        background-color: #0056b3;
    }

    QPushButton:pressed {
        background-color: #004085;
    }

    QPushButton:disabled {
        background-color: #6c757d;
        color: #ced4da;
    }

    QLineEdit, QComboBox, QDateEdit, QSpinBox, QDoubleSpinBox {
        padding: 6px;
        border: 1px solid #ced4da;
        border-radius: 4px;
        background-color: white;
    }

    QLineEdit:focus, QComboBox:focus, QDateEdit:focus, 
    QSpinBox:focus, QDoubleSpinBox:focus {
        border-color: #80bdff;
        outline: none;
    }

    QTableWidget {
        background-color: white;
        alternate-background-color: #f8f9fa;
        selection-background-color: #cce5ff;
        gridline-color: #dee2e6;
    }

    QTableWidget::item {
        padding: 6px;
    }

    QTableWidget::item:selected {
        background-color: #007bff;
        color: white;
    }

    QHeaderView::section {
        background-color: #343a40;
        color: white;
        padding: 8px;
        border: none;
        font-weight: bold;
    }

    QGroupBox {
        font-weight: bold;
        border: 2px solid #dee2e6;
        border-radius: 6px;
        margin-top: 10px;
        padding-top: 10px;
    }

    QGroupBox::title {
        subcontrol-origin: margin;
        left: 10px;
        padding: 0 5px 0 5px;
    }

    QStatusBar {
        background-color: #343a40;
        color: white;
    }

    QToolBar {
        background-color: #e9ecef;
        border-bottom: 1px solid #dee2e6;
        spacing: 5px;
    }

    QMenuBar {
        background-color: #343a40;
        color: white;
    }

    QMenuBar::item:selected {
        background-color: #495057;
    }

    QMenu {
        background-color: white;
        border: 1px solid #dee2e6;
    }

    QMenu::item:selected {
        background-color: #007bff;
        color: white;
    }

    QDialog {
        background-color: white;
    }

    QLabel {
        color: #212529;
    }

    QLabel[title="true"] {
        font-weight: bold;
        font-size: 12pt;
        color: #343a40;
    }

    /* Стили для разных статусов */
    .status-available {
        background-color: #d4edda;
        color: #155724;
        font-weight: bold;
        padding: 2px 8px;
        border-radius: 3px;
    }

    .status-sold {
        background-color: #f8d7da;
        color: #721c24;
        font-weight: bold;
        padding: 2px 8px;
        border-radius: 3px;
    }

    .status-reserved {
        background-color: #fff3cd;
        color: #856404;
        font-weight: bold;
        padding: 2px 8px;
        border-radius: 3px;
    }

    .status-service {
        background-color: #d1ecf1;
        color: #0c5460;
        font-weight: bold;
        padding: 2px 8px;
        border-radius: 3px;
    }

    /* Стили для кнопок действий */
    .btn-success {
        background-color: #28a745;
    }

    .btn-success:hover {
        background-color: #218838;
    }

    .btn-warning {
        background-color: #ffc107;
        color: #212529;
    }

    .btn-warning:hover {
        background-color: #e0a800;
    }

    .btn-danger {
        background-color: #dc3545;
    }

    .btn-danger:hover {
        background-color: #c82333;
    }

    .btn-info {
        background-color: #17a2b8;
    }

    .btn-info:hover {
        background-color: #138496;
    }
    """