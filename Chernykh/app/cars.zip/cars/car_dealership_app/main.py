import os
import sys

# РЕШЕНИЕ ПРОБЛЕМЫ С QT PLUGINS НА WINDOWS
if sys.platform == 'win32':
    # Указываем точный путь к плагинам Qt
    qt_plugin_path = r'C:\Users\юляка\AppData\Roaming\Python\Python311\site-packages\PyQt5\Qt5\plugins'
    os.environ['QT_PLUGIN_PATH'] = qt_plugin_path

    # Также добавляем путь в sys.path для надежности
    if qt_plugin_path not in sys.path:
        sys.path.append(qt_plugin_path)

    print(f"QT_PLUGIN_PATH установлен: {qt_plugin_path}")

"""
Главный файл приложения - точка входа
"""
import sys
import os
from PyQt5.QtWidgets import QApplication, QSplashScreen
from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtGui import QPixmap

from ui_main_window import MainWindow


class CarDealershipApp:
    """Основной класс приложения"""

    def __init__(self):
        self.app = QApplication(sys.argv)
        self.window = None

    def show_splash_screen(self):
        """Показать заставку при запуске"""
        splash_pix = QPixmap(300, 200)
        splash_pix.fill(Qt.white)

        splash = QSplashScreen(splash_pix)
        splash.showMessage(
            "Загрузка Автомобильного центра...\n"
            "Подключение к базе данных...",
            Qt.AlignBottom | Qt.AlignCenter,
            Qt.black
        )
        splash.show()

        # Имитация загрузки
        QTimer.singleShot(2000, lambda: self.show_main_window(splash))

        return splash

    def show_main_window(self, splash):
        """Показать главное окно"""
        self.window = MainWindow()
        self.window.show()
        splash.finish(self.window)

    def run(self):
        """Запуск приложения"""
        splash = self.show_splash_screen()
        sys.exit(self.app.exec_())


def main():
    """Точка входа в приложение"""
    # Проверка наличия необходимых файлов
    required_files = ['database.py', 'ui_main_window.py', 'dialogs.py',
                      'widgets.py', 'styles.py']

    for file in required_files:
        if not os.path.exists(file):
            print(f"Ошибка: отсутствует файл {file}")
            return

    # Запуск приложения
    app = CarDealershipApp()
    app.run()


if __name__ == "__main__":
    main()