"""
Диалоговые окна приложения
"""
from PyQt5.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QFormLayout,
    QLabel, QLineEdit, QComboBox, QPushButton,
    QDateEdit, QSpinBox, QDoubleSpinBox, QTextEdit,
    QGroupBox, QMessageBox, QTableWidget, QTableWidgetItem,
    QTabWidget, QWidget, QHeaderView, QDialogButtonBox, QFileDialog
)
from PyQt5.QtCore import Qt, QDate
from PyQt5.QtGui import QFont
import pandas as pd


class AddCarDialog(QDialog):
    """Диалог добавления автомобиля"""

    def __init__(self, db, parent=None):
        super().__init__(parent)
        self.db = db
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle("Добавить автомобиль")
        self.setGeometry(200, 200, 600, 500)

        layout = QVBoxLayout(self)

        form = QFormLayout()

        # Основные поля
        self.vin_input = QLineEdit()
        self.vin_input.setMaxLength(17)

        self.brand_input = QLineEdit()
        self.model_input = QLineEdit()

        self.year_input = QSpinBox()
        self.year_input.setRange(1900, QDate.currentDate().year() + 1)
        self.year_input.setValue(QDate.currentDate().year())

        self.color_input = QLineEdit()

        # Технические характеристики
        self.engine_type_input = QComboBox()
        self.engine_type_input.addItems(['Бензин', 'Дизель', 'Электрический', 'Гибрид'])

        self.engine_volume_input = QDoubleSpinBox()
        self.engine_volume_input.setRange(0.5, 10.0)
        self.engine_volume_input.setSingleStep(0.1)
        self.engine_volume_input.setValue(1.6)

        self.power_input = QSpinBox()
        self.power_input.setRange(50, 1000)
        self.power_input.setValue(100)

        self.transmission_input = QComboBox()
        self.transmission_input.addItems(['Механика', 'Автомат', 'Робот', 'Вариатор'])

        self.drive_type_input = QComboBox()
        self.drive_type_input.addItems(['Передний', 'Задний', 'Полный'])

        # Цены и статус
        self.purchase_price_input = QDoubleSpinBox()
        self.purchase_price_input.setRange(0, 100000000)
        self.purchase_price_input.setSingleStep(10000)
        self.purchase_price_input.setPrefix("₽ ")

        self.sale_price_input = QDoubleSpinBox()
        self.sale_price_input.setRange(0, 100000000)
        self.sale_price_input.setSingleStep(10000)
        self.sale_price_input.setPrefix("₽ ")

        self.status_input = QComboBox()
        if self.db.connect():
            self.status_input.addItems(self.db.get_car_status_types())

        # Поставщик
        self.supplier_input = QComboBox()
        suppliers = self.db.get_suppliers()
        for supplier in suppliers:
            self.supplier_input.addItem(supplier['name'], supplier['supplier_id'])

        # Поля формы
        form.addRow("VIN:", self.vin_input)
        form.addRow("Марка:", self.brand_input)
        form.addRow("Модель:", self.model_input)
        form.addRow("Год выпуска:", self.year_input)
        form.addRow("Цвет:", self.color_input)
        form.addRow("Тип двигателя:", self.engine_type_input)
        form.addRow("Объем двигателя (л):", self.engine_volume_input)
        form.addRow("Мощность (л.с.):", self.power_input)
        form.addRow("Коробка передач:", self.transmission_input)
        form.addRow("Привод:", self.drive_type_input)
        form.addRow("Цена закупки:", self.purchase_price_input)
        form.addRow("Цена продажи:", self.sale_price_input)
        form.addRow("Статус:", self.status_input)
        form.addRow("Поставщик:", self.supplier_input)

        layout.addLayout(form)

        # Кнопки
        button_layout = QHBoxLayout()

        self.save_btn = QPushButton("Сохранить")
        self.save_btn.clicked.connect(self.save_car)

        self.cancel_btn = QPushButton("Отмена")
        self.cancel_btn.clicked.connect(self.reject)

        button_layout.addWidget(self.save_btn)
        button_layout.addWidget(self.cancel_btn)

        layout.addLayout(button_layout)

    def save_car(self):
        """Сохранение автомобиля"""
        if not self.vin_input.text().strip():
            QMessageBox.warning(self, "Ошибка", "Введите VIN")
            return

        if not self.brand_input.text().strip():
            QMessageBox.warning(self, "Ошибка", "Введите марку")
            return

        if not self.model_input.text().strip():
            QMessageBox.warning(self, "Ошибка", "Введите модель")
            return

        if self.supplier_input.currentData() is None:
            QMessageBox.warning(self, "Ошибка", "Выберите поставщика")
            return

        car_data = {
            'vin': self.vin_input.text().strip(),
            'brand': self.brand_input.text().strip(),
            'model': self.model_input.text().strip(),
            'year': self.year_input.value(),
            'color': self.color_input.text().strip(),
            'engine_type': self.engine_type_input.currentText(),
            'engine_volume': self.engine_volume_input.value(),
            'power': self.power_input.value(),
            'transmission': self.transmission_input.currentText(),
            'drive_type': self.drive_type_input.currentText(),
            'trim_level': '',
            'purchase_price': self.purchase_price_input.value(),
            'sale_price': self.sale_price_input.value() if self.sale_price_input.value() > 0 else None,
            'status': self.status_input.currentText(),
            'supplier_id': self.supplier_input.currentData()
        }

        try:
            car_id = self.db.add_car(car_data)
            if car_id:
                self.accept()
            else:
                QMessageBox.critical(self, "Ошибка", "Не удалось добавить автомобиль")
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Ошибка при добавлении: {str(e)}")


class AddClientDialog(QDialog):
    """Диалог добавления клиента"""

    def __init__(self, db, parent=None):
        super().__init__(parent)
        self.db = db
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle("Добавить клиента")
        self.setGeometry(200, 200, 500, 400)

        layout = QVBoxLayout(self)

        self.tabs = QTabWidget()

        # Вкладка для физ. лиц
        self.individual_tab = self.create_individual_tab()
        self.tabs.addTab(self.individual_tab, "Физическое лицо")

        # Вкладка для юр. лиц
        self.legal_tab = self.create_legal_tab()
        self.tabs.addTab(self.legal_tab, "Юридическое лицо")

        layout.addWidget(self.tabs)

        # Общие поля
        common_group = QGroupBox("Контактная информация")
        common_layout = QFormLayout()

        self.phone_input = QLineEdit()
        self.email_input = QLineEdit()
        self.address_input = QTextEdit()
        self.address_input.setMaximumHeight(80)

        common_layout.addRow("Телефон:", self.phone_input)
        common_layout.addRow("Email:", self.email_input)
        common_layout.addRow("Адрес:", self.address_input)

        common_group.setLayout(common_layout)
        layout.addWidget(common_group)

        # Кнопки
        button_layout = QHBoxLayout()

        self.save_btn = QPushButton("Сохранить")
        self.save_btn.clicked.connect(self.save_client)

        self.cancel_btn = QPushButton("Отмена")
        self.cancel_btn.clicked.connect(self.reject)

        button_layout.addWidget(self.save_btn)
        button_layout.addWidget(self.cancel_btn)

        layout.addLayout(button_layout)

    def create_individual_tab(self):
        """Создание вкладки для физ. лиц"""
        widget = QWidget()
        layout = QFormLayout(widget)

        self.ind_last_name = QLineEdit()
        self.ind_first_name = QLineEdit()
        self.ind_middle_name = QLineEdit()
        self.ind_passport = QLineEdit()

        layout.addRow("Фамилия:", self.ind_last_name)
        layout.addRow("Имя:", self.ind_first_name)
        layout.addRow("Отчество:", self.ind_middle_name)
        layout.addRow("Паспорт:", self.ind_passport)

        return widget

    def create_legal_tab(self):
        """Создание вкладки для юр. лиц"""
        widget = QWidget()
        layout = QFormLayout(widget)

        self.legal_name = QLineEdit()
        self.legal_inn = QLineEdit()

        layout.addRow("Название компании:", self.legal_name)
        layout.addRow("ИНН:", self.legal_inn)

        return widget

    def save_client(self):
        """Сохранение клиента"""
        if not self.phone_input.text().strip():
            QMessageBox.warning(self, "Ошибка", "Введите телефон")
            return

        client_data = {}

        if self.tabs.currentIndex() == 0:  # Физ. лицо
            if not self.ind_last_name.text().strip():
                QMessageBox.warning(self, "Ошибка", "Введите фамилию")
                return

            if not self.ind_passport.text().strip():
                QMessageBox.warning(self, "Ошибка", "Введите паспортные данные")
                return

            client_data.update({
                'last_name': self.ind_last_name.text().strip(),
                'first_name': self.ind_first_name.text().strip(),
                'middle_name': self.ind_middle_name.text().strip(),
                'type': 'Физическое лицо',
                'passport_number': self.ind_passport.text().strip(),
                'company_name': None,
                'inn': None
            })
        else:  # Юр. лицо
            if not self.legal_name.text().strip():
                QMessageBox.warning(self, "Ошибка", "Введите название компании")
                return

            if not self.legal_inn.text().strip():
                QMessageBox.warning(self, "Ошибка", "Введите ИНН")
                return

            client_data.update({
                'last_name': None,
                'first_name': None,
                'middle_name': None,
                'type': 'Юридическое лицо',
                'passport_number': None,
                'company_name': self.legal_name.text().strip(),
                'inn': self.legal_inn.text().strip()
            })

        client_data.update({
            'phone': self.phone_input.text().strip(),
            'email': self.email_input.text().strip() or None,
            'address': self.address_input.toPlainText().strip() or None
        })

        try:
            query = """
                INSERT INTO car_dealership.clients 
                (last_name, first_name, middle_name, type, passport_number, 
                 company_name, inn, phone, email, address)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                RETURNING client_id
            """

            result = self.db.execute_query(query, (
                client_data['last_name'], client_data['first_name'],
                client_data['middle_name'], client_data['type'],
                client_data['passport_number'], client_data['company_name'],
                client_data['inn'], client_data['phone'],
                client_data['email'], client_data['address']
            ))

            if result:
                self.accept()
            else:
                QMessageBox.critical(self, "Ошибка", "Не удалось добавить клиента")

        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Ошибка при добавлении: {str(e)}")


class AddDealDialog(QDialog):
    """Диалог добавления сделки"""

    def __init__(self, db, parent=None):
        super().__init__(parent)
        self.db = db
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle("Новая сделка")
        self.setGeometry(200, 200, 500, 400)

        layout = QVBoxLayout(self)

        form = QFormLayout()

        # Дата
        self.date_input = QDateEdit()
        self.date_input.setDate(QDate.currentDate())
        self.date_input.setCalendarPopup(True)

        # Автомобиль
        self.car_input = QComboBox()
        cars = self.db.get_all_cars('В наличии')
        for car in cars:
            display = f"{car['brand']} {car['model']} ({car['year']}) - {car['sale_price'] or car['purchase_price']:,.0f} ₽"
            self.car_input.addItem(display, car['car_id'])

        # Клиент
        self.client_input = QComboBox()
        clients = self.db.get_all_clients()
        for client in clients:
            if client['type'] == 'Физическое лицо':
                display = f"{client['last_name']} {client['first_name']} ({client['phone']})"
            else:
                display = f"{client['company_name']} ({client['phone']})"
            self.client_input.addItem(display, client['client_id'])

        # Менеджер
        self.employee_input = QComboBox()
        employees = self.db.get_employees()
        # Фильтруем только менеджеров по продажам
        managers = [e for e in employees if 'менеджер' in e['position_name'].lower()]
        for emp in managers:
            display = f"{emp['last_name']} {emp['first_name']}"
            self.employee_input.addItem(display, emp['employee_id'])

        # Сумма и способ оплаты
        self.price_input = QDoubleSpinBox()
        self.price_input.setRange(0, 100000000)
        self.price_input.setSingleStep(10000)
        self.price_input.setPrefix("₽ ")

        self.payment_input = QComboBox()
        self.payment_input.addItems(self.db.get_payment_methods())

        # Статус
        self.status_input = QComboBox()
        self.status_input.addItems(['Оформлена', 'Оплачена', 'Завершена'])

        form.addRow("Дата сделки:", self.date_input)
        form.addRow("Автомобиль:", self.car_input)
        form.addRow("Клиент:", self.client_input)
        form.addRow("Менеджер:", self.employee_input)
        form.addRow("Сумма:", self.price_input)
        form.addRow("Способ оплаты:", self.payment_input)
        form.addRow("Статус:", self.status_input)

        layout.addLayout(form)

        # Информация о выбранном автомобиле
        self.car_info_label = QLabel()
        self.car_info_label.setWordWrap(True)
        layout.addWidget(self.car_info_label)

        # Обновляем информацию при выборе автомобиля
        self.car_input.currentIndexChanged.connect(self.update_car_info)
        if self.car_input.count() > 0:
            self.update_car_info()

        # Кнопки
        button_layout = QHBoxLayout()

        self.save_btn = QPushButton("Сохранить")
        self.save_btn.clicked.connect(self.save_deal)

        self.cancel_btn = QPushButton("Отмена")
        self.cancel_btn.clicked.connect(self.reject)

        button_layout.addWidget(self.save_btn)
        button_layout.addWidget(self.cancel_btn)

        layout.addLayout(button_layout)

    def update_car_info(self):
        """Обновление информации о выбранном автомобиле"""
        car_id = self.car_input.currentData()
        if car_id:
            try:
                car = self.db.get_car_by_id(car_id)
                if car:
                    info = f"""
                    <b>Информация об автомобиле:</b><br>
                    {car['brand']} {car['model']} ({car['year']})<br>
                    Цвет: {car['color']}<br>
                    Двигатель: {car['engine_type']} {car['engine_volume']}л, {car['power']} л.с.<br>
                    КПП: {car['transmission']}, Привод: {car['drive_type']}<br>
                    Цена продажи: {car['sale_price'] or car['purchase_price']:,.0f} ₽
                    """
                    self.car_info_label.setText(info)

                    # Устанавливаем цену автомобиля как начальную цену сделки
                    suggested_price = car['sale_price'] or car['purchase_price']
                    self.price_input.setValue(float(suggested_price))
            except:
                pass

    def save_deal(self):
        """Сохранение сделки"""
        if self.car_input.currentData() is None:
            QMessageBox.warning(self, "Ошибка", "Выберите автомобиль")
            return

        if self.client_input.currentData() is None:
            QMessageBox.warning(self, "Ошибка", "Выберите клиента")
            return

        if self.employee_input.currentData() is None:
            QMessageBox.warning(self, "Ошибка", "Выберите менеджера")
            return

        deal_data = {
            'deal_date': self.date_input.date().toString("yyyy-MM-dd"),
            'car_id': self.car_input.currentData(),
            'client_id': self.client_input.currentData(),
            'employee_id': self.employee_input.currentData(),
            'final_price': self.price_input.value(),
            'payment_method': self.payment_input.currentText(),
            'deal_status': self.status_input.currentText()
        }

        try:
            deal_id = self.db.create_deal(deal_data)
            if deal_id:
                self.accept()
            else:
                QMessageBox.critical(self, "Ошибка", "Не удалось создать сделку")
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Ошибка при создании: {str(e)}")


class EditCarDialog(AddCarDialog):
    """Диалог редактирования автомобиля"""

    def __init__(self, db, car_id, parent=None):
        self.car_id = car_id
        super().__init__(db, parent)
        self.setWindowTitle("Редактировать автомобиль")
        self.load_car_data()

    def load_car_data(self):
        """Загрузка данных автомобиля"""
        try:
            car = self.db.get_car_by_id(self.car_id)
            if car:
                self.vin_input.setText(car['vin'])
                self.brand_input.setText(car['brand'])
                self.model_input.setText(car['model'])
                self.year_input.setValue(car['year'])
                self.color_input.setText(car['color'] or '')

                self.engine_type_input.setCurrentText(car['engine_type'])
                self.engine_volume_input.setValue(float(car['engine_volume']) if car['engine_volume'] else 0)
                self.power_input.setValue(car['power'] or 0)
                self.transmission_input.setCurrentText(car['transmission'])
                self.drive_type_input.setCurrentText(car['drive_type'])

                self.purchase_price_input.setValue(float(car['purchase_price']))
                if car['sale_price']:
                    self.sale_price_input.setValue(float(car['sale_price']))

                self.status_input.setCurrentText(car['status'])

                # Установка поставщика
                index = self.supplier_input.findData(car['supplier_id'])
                if index >= 0:
                    self.supplier_input.setCurrentIndex(index)

        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Ошибка загрузки данных: {str(e)}")

    def save_car(self):
        """Сохранение изменений"""
        if not self.vin_input.text().strip():
            QMessageBox.warning(self, "Ошибка", "Введите VIN")
            return

        car_data = {
            'vin': self.vin_input.text().strip(),
            'brand': self.brand_input.text().strip(),
            'model': self.model_input.text().strip(),
            'year': self.year_input.value(),
            'color': self.color_input.text().strip(),
            'engine_type': self.engine_type_input.currentText(),
            'engine_volume': self.engine_volume_input.value(),
            'power': self.power_input.value(),
            'transmission': self.transmission_input.currentText(),
            'drive_type': self.drive_type_input.currentText(),
            'trim_level': '',
            'purchase_price': self.purchase_price_input.value(),
            'sale_price': self.sale_price_input.value() if self.sale_price_input.value() > 0 else None,
            'status': self.status_input.currentText(),
            'supplier_id': self.supplier_input.currentData()
        }

        try:
            query = """
                UPDATE car_dealership.cars SET
                    vin = %s, brand = %s, model = %s, year = %s, color = %s,
                    engine_type = %s, engine_volume = %s, power = %s,
                    transmission = %s, drive_type = %s, trim_level = %s,
                    purchase_price = %s, sale_price = %s, status = %s,
                    supplier_id = %s
                WHERE car_id = %s
            """

            self.db.execute_query(query, (
                car_data['vin'], car_data['brand'], car_data['model'],
                car_data['year'], car_data['color'], car_data['engine_type'],
                car_data['engine_volume'], car_data['power'],
                car_data['transmission'], car_data['drive_type'],
                car_data['trim_level'], car_data['purchase_price'],
                car_data['sale_price'], car_data['status'],
                car_data['supplier_id'], self.car_id
            ), fetch=False)

            self.accept()

        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Ошибка при обновлении: {str(e)}")


class EditClientDialog(QDialog):
    """Диалог редактирования клиента"""

    def __init__(self, db, client_id, parent=None):
        super().__init__(parent)
        self.db = db
        self.client_id = client_id
        self.init_ui()
        self.load_client_data()

    def init_ui(self):
        self.setWindowTitle("Редактировать клиента")
        self.setGeometry(200, 200, 500, 400)

        layout = QVBoxLayout(self)

        self.tabs = QTabWidget()

        # Вкладка для физ. лиц
        self.individual_tab = self.create_individual_tab()
        self.tabs.addTab(self.individual_tab, "Физическое лицо")

        # Вкладка для юр. лиц
        self.legal_tab = self.create_legal_tab()
        self.tabs.addTab(self.legal_tab, "Юридическое лицо")

        layout.addWidget(self.tabs)

        # Общие поля
        common_group = QGroupBox("Контактная информация")
        common_layout = QFormLayout()

        self.phone_input = QLineEdit()
        self.email_input = QLineEdit()
        self.address_input = QTextEdit()
        self.address_input.setMaximumHeight(80)

        common_layout.addRow("Телефон:", self.phone_input)
        common_layout.addRow("Email:", self.email_input)
        common_layout.addRow("Адрес:", self.address_input)

        common_group.setLayout(common_layout)
        layout.addWidget(common_group)

        # Кнопки
        button_layout = QHBoxLayout()

        self.save_btn = QPushButton("Сохранить")
        self.save_btn.clicked.connect(self.save_client)

        self.cancel_btn = QPushButton("Отмена")
        self.cancel_btn.clicked.connect(self.reject)

        button_layout.addWidget(self.save_btn)
        button_layout.addWidget(self.cancel_btn)

        layout.addLayout(button_layout)

    def create_individual_tab(self):
        """Создание вкладки для физ. лиц"""
        widget = QWidget()
        layout = QFormLayout(widget)

        self.ind_last_name = QLineEdit()
        self.ind_first_name = QLineEdit()
        self.ind_middle_name = QLineEdit()
        self.ind_passport = QLineEdit()

        layout.addRow("Фамилия:", self.ind_last_name)
        layout.addRow("Имя:", self.ind_first_name)
        layout.addRow("Отчество:", self.ind_middle_name)
        layout.addRow("Паспорт:", self.ind_passport)

        return widget

    def create_legal_tab(self):
        """Создание вкладки для юр. лиц"""
        widget = QWidget()
        layout = QFormLayout(widget)

        self.legal_name = QLineEdit()
        self.legal_inn = QLineEdit()

        layout.addRow("Название компании:", self.legal_name)
        layout.addRow("ИНН:", self.legal_inn)

        return widget

    def load_client_data(self):
        """Загрузка данных клиента"""
        try:
            query = "SELECT * FROM car_dealership.clients WHERE client_id = %s"
            result = self.db.execute_query(query, (self.client_id,))

            if result:
                client = result[0]

                # Заполнение общих полей
                self.phone_input.setText(client['phone'])
                self.email_input.setText(client['email'] or '')
                self.address_input.setText(client['address'] or '')

                # Установка соответствующей вкладки
                if client['type'] == 'Физическое лицо':
                    self.tabs.setCurrentIndex(0)
                    self.ind_last_name.setText(client['last_name'] or '')
                    self.ind_first_name.setText(client['first_name'] or '')
                    self.ind_middle_name.setText(client['middle_name'] or '')
                    self.ind_passport.setText(client['passport_number'] or '')
                else:
                    self.tabs.setCurrentIndex(1)
                    self.legal_name.setText(client['company_name'] or '')
                    self.legal_inn.setText(client['inn'] or '')

        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Ошибка загрузки данных: {str(e)}")

    def save_client(self):
        """Сохранение изменений"""
        if not self.phone_input.text().strip():
            QMessageBox.warning(self, "Ошибка", "Введите телефон")
            return

        try:
            if self.tabs.currentIndex() == 0:  # Физ. лицо
                client_data = {
                    'last_name': self.ind_last_name.text().strip(),
                    'first_name': self.ind_first_name.text().strip(),
                    'middle_name': self.ind_middle_name.text().strip() or None,
                    'type': 'Физическое лицо',
                    'passport_number': self.ind_passport.text().strip(),
                    'company_name': None,
                    'inn': None
                }
            else:  # Юр. лицо
                client_data = {
                    'last_name': None,
                    'first_name': None,
                    'middle_name': None,
                    'type': 'Юридическое лицо',
                    'passport_number': None,
                    'company_name': self.legal_name.text().strip(),
                    'inn': self.legal_inn.text().strip()
                }

            client_data.update({
                'phone': self.phone_input.text().strip(),
                'email': self.email_input.text().strip() or None,
                'address': self.address_input.toPlainText().strip() or None
            })

            query = """
                UPDATE car_dealership.clients SET
                    last_name = %s, first_name = %s, middle_name = %s,
                    type = %s, passport_number = %s, company_name = %s,
                    inn = %s, phone = %s, email = %s, address = %s
                WHERE client_id = %s
            """

            self.db.execute_query(query, (
                client_data['last_name'], client_data['first_name'],
                client_data['middle_name'], client_data['type'],
                client_data['passport_number'], client_data['company_name'],
                client_data['inn'], client_data['phone'],
                client_data['email'], client_data['address'],
                self.client_id
            ), fetch=False)

            self.accept()

        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Ошибка при обновлении: {str(e)}")


class EditDealDialog(QDialog):
    """Диалог редактирования сделки"""

    def __init__(self, db, deal_id, parent=None):
        super().__init__(parent)
        self.db = db
        self.deal_id = deal_id
        self.init_ui()
        self.load_deal_data()

    def init_ui(self):
        self.setWindowTitle("Редактировать сделку")
        self.setGeometry(200, 200, 500, 400)

        layout = QVBoxLayout(self)

        form = QFormLayout()

        # Дата
        self.date_input = QDateEdit()
        self.date_input.setCalendarPopup(True)

        # Автомобиль (только проданные или забронированные)
        self.car_input = QComboBox()
        cars = self.db.get_all_cars()
        for car in cars:
            if car['status'] in ['Продан', 'Забронирован']:
                display = f"{car['brand']} {car['model']} ({car['year']}) - {car['status']}"
                self.car_input.addItem(display, car['car_id'])

        # Клиент
        self.client_input = QComboBox()
        clients = self.db.get_all_clients()
        for client in clients:
            if client['type'] == 'Физическое лицо':
                display = f"{client['last_name']} {client['first_name']} ({client['phone']})"
            else:
                display = f"{client['company_name']} ({client['phone']})"
            self.client_input.addItem(display, client['client_id'])

        # Менеджер
        self.employee_input = QComboBox()
        employees = self.db.get_employees()
        managers = [e for e in employees if 'менеджер' in e['position_name'].lower()]
        for emp in managers:
            display = f"{emp['last_name']} {emp['first_name']}"
            self.employee_input.addItem(display, emp['employee_id'])

        # Сумма и способ оплаты
        self.price_input = QDoubleSpinBox()
        self.price_input.setRange(0, 100000000)
        self.price_input.setSingleStep(10000)
        self.price_input.setPrefix("₽ ")

        self.payment_input = QComboBox()
        self.payment_input.addItems(self.db.get_payment_methods())

        # Статус
        self.status_input = QComboBox()
        self.status_input.addItems(['Оформлена', 'Оплачена', 'Завершена'])

        form.addRow("Дата сделки:", self.date_input)
        form.addRow("Автомобиль:", self.car_input)
        form.addRow("Клиент:", self.client_input)
        form.addRow("Менеджер:", self.employee_input)
        form.addRow("Сумма:", self.price_input)
        form.addRow("Способ оплаты:", self.payment_input)
        form.addRow("Статус:", self.status_input)

        layout.addLayout(form)

        # Информация о сделке
        self.deal_info_label = QLabel()
        self.deal_info_label.setWordWrap(True)
        layout.addWidget(self.deal_info_label)

        # Кнопки
        button_layout = QHBoxLayout()

        self.save_btn = QPushButton("Сохранить")
        self.save_btn.clicked.connect(self.save_deal)

        self.cancel_btn = QPushButton("Отмена")
        self.cancel_btn.clicked.connect(self.reject)

        button_layout.addWidget(self.save_btn)
        button_layout.addWidget(self.cancel_btn)

        layout.addLayout(button_layout)

    def load_deal_data(self):
        """Загрузка данных сделки"""
        try:
            query = "SELECT * FROM car_dealership.deals WHERE deal_id = %s"
            result = self.db.execute_query(query, (self.deal_id,))

            if result:
                deal = result[0]

                # Заполнение полей
                self.date_input.setDate(QDate.fromString(str(deal['deal_date']), "yyyy-MM-dd"))
                self.price_input.setValue(float(deal['final_price']))

                # Установка автомобиля
                car_index = self.car_input.findData(deal['car_id'])
                if car_index >= 0:
                    self.car_input.setCurrentIndex(car_index)

                # Установка клиента
                client_index = self.client_input.findData(deal['client_id'])
                if client_index >= 0:
                    self.client_input.setCurrentIndex(client_index)

                # Установка менеджера
                employee_index = self.employee_input.findData(deal['employee_id'])
                if employee_index >= 0:
                    self.employee_input.setCurrentIndex(employee_index)

                # Установка способа оплаты и статуса
                self.payment_input.setCurrentText(deal['payment_method'])
                self.status_input.setCurrentText(deal['deal_status'])

                # Получение информации об автомобиле
                car_query = "SELECT * FROM car_dealership.cars WHERE car_id = %s"
                car_result = self.db.execute_query(car_query, (deal['car_id'],))

                if car_result:
                    car = car_result[0]
                    info = f"""
                    <b>Связанный автомобиль:</b><br>
                    {car['brand']} {car['model']} ({car['year']})<br>
                    VIN: {car['vin']}<br>
                    Статус: {car['status']}<br>
                    <b>ID сделки:</b> {self.deal_id}
                    """
                    self.deal_info_label.setText(info)

        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Ошибка загрузки данных: {str(e)}")

    def save_deal(self):
        """Сохранение изменений"""
        if self.car_input.currentData() is None:
            QMessageBox.warning(self, "Ошибка", "Выберите автомобиль")
            return

        if self.client_input.currentData() is None:
            QMessageBox.warning(self, "Ошибка", "Выберите клиента")
            return

        if self.employee_input.currentData() is None:
            QMessageBox.warning(self, "Ошибка", "Выберите менеджера")
            return

        try:
            deal_data = {
                'deal_date': self.date_input.date().toString("yyyy-MM-dd"),
                'car_id': self.car_input.currentData(),
                'client_id': self.client_input.currentData(),
                'employee_id': self.employee_input.currentData(),
                'final_price': self.price_input.value(),
                'payment_method': self.payment_input.currentText(),
                'deal_status': self.status_input.currentText()
            }

            query = """
                UPDATE car_dealership.deals SET
                    deal_date = %s, car_id = %s, client_id = %s, 
                    employee_id = %s, final_price = %s, 
                    payment_method = %s, deal_status = %s
                WHERE deal_id = %s
            """

            self.db.execute_query(query, (
                deal_data['deal_date'], deal_data['car_id'],
                deal_data['client_id'], deal_data['employee_id'],
                deal_data['final_price'], deal_data['payment_method'],
                deal_data['deal_status'], self.deal_id
            ), fetch=False)

            self.accept()

        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Ошибка при обновлении: {str(e)}")


class ViewDetailsDialog(QDialog):
    """Диалог просмотра детальной информации"""

    def __init__(self, db, object_type, object_id, parent=None):
        super().__init__(parent)
        self.db = db
        self.object_type = object_type
        self.object_id = object_id
        self.init_ui()
        self.load_data()

    def init_ui(self):
        if self.object_type == 'car':
            self.setWindowTitle("Детали автомобиля")
            self.setGeometry(200, 200, 600, 500)
        elif self.object_type == 'deal':
            self.setWindowTitle("Детали сделки")
            self.setGeometry(200, 200, 700, 500)
        else:
            self.setWindowTitle("Детали")
            self.setGeometry(200, 200, 500, 400)

        layout = QVBoxLayout(self)

        # Основной текст
        self.text_edit = QTextEdit()
        self.text_edit.setReadOnly(True)
        self.text_edit.setFont(QFont("Consolas", 10))

        layout.addWidget(self.text_edit)

        # Кнопки
        button_layout = QHBoxLayout()

        close_btn = QPushButton("Закрыть")
        close_btn.clicked.connect(self.accept)

        if self.object_type == 'deal':
            print_btn = QPushButton("Печать договора")
            print_btn.clicked.connect(self.print_contract)
            button_layout.addWidget(print_btn)

        button_layout.addStretch()
        button_layout.addWidget(close_btn)

        layout.addLayout(button_layout)

    def load_data(self):
        """Загрузка данных в зависимости от типа объекта"""
        try:
            if self.object_type == 'car':
                self.load_car_data()
            elif self.object_type == 'deal':
                self.load_deal_data()

        except Exception as e:
            self.text_edit.setText(f"Ошибка загрузки данных: {str(e)}")

    def load_car_data(self):
        """Загрузка данных об автомобиле"""
        car = self.db.get_car_by_id(self.object_id)

        if car:
            text = f"""
{'=' * 60}
ДЕТАЛЬНАЯ ИНФОРМАЦИЯ ОБ АВТОМОБИЛЕ
{'=' * 60}

ОСНОВНЫЕ ДАННЫЕ:
{'=' * 60}
ID: {car['car_id']}
VIN: {car['vin']}
Марка: {car['brand']}
Модель: {car['model']}
Год выпуска: {car['year']}
Цвет: {car['color'] or 'Не указан'}
Пробег: {car['mileage'] or 0} км
Дата поступления: {car['arrival_date']}
Статус: {car['status']}

ТЕХНИЧЕСКИЕ ХАРАКТЕРИСТИКИ:
{'=' * 60}
Тип двигателя: {car['engine_type']}
Объем двигателя: {car['engine_volume']} л
Мощность: {car['power']} л.с.
Коробка передач: {car['transmission']}
Привод: {car['drive_type']}
Комплектация: {car['trim_level'] or 'Стандарт'}

ФИНАНСОВАЯ ИНФОРМАЦИЯ:
{'=' * 60}
Цена закупки: {car['purchase_price']:,.0f} ₽
Цена продажи: {car['sale_price']:,.0f if car['sale_price'] else 'Не установлена'} ₽
Наценка: {((car['sale_price'] or car['purchase_price']) - car['purchase_price']):,.0f if car['sale_price'] else 'N/A'} ₽

ПОСТАВЩИК:
{'=' * 60}
ID поставщика: {car['supplier_id']}
Название: {car.get('supplier_name', 'Неизвестно')}

{'=' * 60}
            """
            self.text_edit.setText(text)

    def load_deal_data(self):
        """Загрузка данных о сделке"""
        try:
            # Получение данных сделки
            deal_query = """
                SELECT d.*, 
                       c.brand, c.model, c.year, c.vin, c.purchase_price,
                       cl.last_name, cl.first_name, cl.type, cl.company_name, cl.phone as client_phone,
                       e.last_name as emp_last, e.first_name as emp_first
                FROM car_dealership.deals d
                JOIN car_dealership.cars c ON d.car_id = c.car_id
                JOIN car_dealership.clients cl ON d.client_id = cl.client_id
                JOIN car_dealership.employees e ON d.employee_id = e.employee_id
                WHERE d.deal_id = %s
            """

            result = self.db.execute_query(deal_query, (self.object_id,))

            if result:
                deal = result[0]

                # Расчет прибыли
                profit = deal['final_price'] - deal['purchase_price']
                profit_percent = (profit / deal['purchase_price'] * 100) if deal['purchase_price'] > 0 else 0

                # Формирование текста
                text = f"""
{'=' * 60}
ДЕТАЛИ СДЕЛКИ №{deal['deal_id']}
{'=' * 60}

ОСНОВНАЯ ИНФОРМАЦИЯ:
{'=' * 60}
ID сделки: {deal['deal_id']}
Дата сделки: {deal['deal_date']}
Статус: {deal['deal_status']}
Способ оплаты: {deal['payment_method']}

АВТОМОБИЛЬ:
{'=' * 60}
Марка/Модель: {deal['brand']} {deal['model']}
Год выпуска: {deal['year']}
VIN: {deal['vin']}
Цена закупки: {deal['purchase_price']:,.0f} ₽

КЛИЕНТ:
{'=' * 60}
Тип: {deal['type']}
"""

                if deal['type'] == 'Физическое лицо':
                    text += f"""ФИО: {deal['last_name']} {deal['first_name']}
"""
                else:
                    text += f"""Компания: {deal['company_name']}
"""

                text += f"""Телефон: {deal['client_phone']}

МЕНЕДЖЕР:
{'=' * 60}
ФИО: {deal['emp_last']} {deal['emp_first']}

ФИНАНСОВЫЕ ДАННЫЕ:
{'=' * 60}
Сумма сделки: {deal['final_price']:,.0f} ₽
Цена закупки: {deal['purchase_price']:,.0f} ₽
Прибыль: {profit:,.0f} ₽
Рентабельность: {profit_percent:.2f}%

{'=' * 60}
                """

                self.text_edit.setText(text)

        except Exception as e:
            self.text_edit.setText(f"Ошибка загрузки данных сделки: {str(e)}")

    def print_contract(self):
        """Печать договора"""
        QMessageBox.information(self, "Информация",
                                "Функция печати договора в разработке.\n"
                                "Детали сделки можно скопировать из этого окна.")


class ReportDialog(QDialog):
    """Диалог просмотра отчетов"""

    def __init__(self, dataframe, title, parent=None):
        super().__init__(parent)
        self.dataframe = dataframe
        self.title = title
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle(self.title)
        self.setGeometry(100, 100, 1000, 600)

        layout = QVBoxLayout(self)

        # Информация о отчете
        info_label = QLabel(f"Отчет содержит {len(self.dataframe)} записей")
        layout.addWidget(info_label)

        # Таблица с данными
        self.table = QTableWidget()
        self.table.setRowCount(len(self.dataframe))
        self.table.setColumnCount(len(self.dataframe.columns))
        self.table.setHorizontalHeaderLabels(self.dataframe.columns)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)

        # Заполнение таблицы
        for i in range(len(self.dataframe)):
            for j in range(len(self.dataframe.columns)):
                value = self.dataframe.iloc[i, j]
                if isinstance(value, (int, float)) and not isinstance(value, bool):
                    # Форматирование числовых значений
                    if 'price' in self.dataframe.columns[j].lower() or 'сумма' in self.dataframe.columns[j].lower():
                        display_value = f"{value:,.0f} ₽"
                    else:
                        display_value = f"{value:,.0f}"
                else:
                    display_value = str(value) if value is not None else ""

                item = QTableWidgetItem(display_value)
                self.table.setItem(i, j, item)

        layout.addWidget(self.table)

        # Кнопки
        button_layout = QHBoxLayout()

        export_btn = QPushButton("Экспорт в Excel")
        export_btn.clicked.connect(self.export_to_excel)

        print_btn = QPushButton("Печать")
        print_btn.clicked.connect(self.print_report)

        close_btn = QPushButton("Закрыть")
        close_btn.clicked.connect(self.accept)

        button_layout.addWidget(export_btn)
        button_layout.addWidget(print_btn)
        button_layout.addWidget(close_btn)

        layout.addLayout(button_layout)

    def export_to_excel(self):
        """Экспорт отчета в Excel"""
        try:
            file_path, _ = QFileDialog.getSaveFileName(
                self, "Сохранить отчет",
                f"{self.title}_{QDate.currentDate().toString('yyyy-MM-dd')}.xlsx",
                "Excel files (*.xlsx);;All files (*.*)"
            )

            if file_path:
                self.dataframe.to_excel(file_path, index=False)
                QMessageBox.information(self, "Успех", f"Отчет сохранен в {file_path}")
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Ошибка экспорта: {str(e)}")

    def print_report(self):
        """Печать отчета"""
        # Здесь можно добавить логику для печати
        QMessageBox.information(self, "Информация", "Функция печати в разработке")