"""
Кастомные виджеты приложения
"""
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QFrame, QGridLayout, QProgressBar
)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont, QPalette, QColor


class StatisticsWidget(QWidget):
    """Виджет отображения статистики"""

    def __init__(self):
        super().__init__()
        self.init_ui()

    def init_ui(self):
        layout = QHBoxLayout(self)
        layout.setSpacing(20)

        # Карточка автомобилей
        self.cars_card = self.create_stat_card("🚗 Автомобили", "0", "всего")
        layout.addWidget(self.cars_card)

        # Карточка клиентов
        self.clients_card = self.create_stat_card("👥 Клиенты", "0", "всего")
        layout.addWidget(self.clients_card)

        # Карточка сделок
        self.deals_card = self.create_stat_card("📝 Сделки", "0", "всего")
        layout.addWidget(self.deals_card)

        # Карточка прибыли
        self.profit_card = self.create_stat_card("💰 Прибыль", "0 ₽", "за месяц")
        layout.addWidget(self.profit_card)

        # Прогресс-бар загрузки
        self.progress_bar = QProgressBar()
        self.progress_bar.setMaximumHeight(10)
        self.progress_bar.setVisible(False)
        layout.addWidget(self.progress_bar)

    def create_stat_card(self, title, value, description):
        """Создание карточки статистики"""
        card = QFrame()
        card.setFrameStyle(QFrame.Box)
        card.setLineWidth(1)
        card.setMaximumHeight(100)

        layout = QVBoxLayout(card)
        layout.setContentsMargins(10, 10, 10, 10)

        title_label = QLabel(title)
        title_label.setFont(QFont("Arial", 10))

        value_label = QLabel(value)
        value_label.setFont(QFont("Arial", 18, QFont.Bold))

        desc_label = QLabel(description)
        desc_label.setFont(QFont("Arial", 8))
        desc_label.setStyleSheet("color: gray")

        layout.addWidget(title_label)
        layout.addWidget(value_label)
        layout.addWidget(desc_label)

        return card

    def update_stats(self, stats):
        """Обновление статистики"""
        # Автомобили
        total_cars = sum(stats.get('cars_by_status', {}).values())
        self.cars_card.findChild(QLabel, None).setText(str(total_cars))

        # Клиенты
        self.clients_card.findChild(QLabel, None).setText(str(stats.get('total_clients', 0)))

        # Сделки (за последний месяц)
        monthly_deals = 0
        if stats.get('monthly_sales'):
            for month in stats['monthly_sales']:
                if month['month'].endswith(QDate.currentDate().toString('MM')):
                    monthly_deals = month['deals_count']
                    break
        self.deals_card.findChild(QLabel, None).setText(str(monthly_deals))

        # Прибыль (за последний месяц)
        monthly_profit = 0
        if stats.get('monthly_sales'):
            for month in stats['monthly_sales']:
                if month['month'].endswith(QDate.currentDate().toString('MM')):
                    monthly_profit = month.get('month_sales', 0)
                    break
        self.profit_card.findChild(QLabel, None).setText(f"{monthly_profit:,.0f} ₽")


class CarCardWidget(QWidget):
    """Виджет карточки автомобиля"""

    def __init__(self, car_data):
        super().__init__()
        self.car_data = car_data
        self.init_ui()

    def init_ui(self):
        self.setFixedSize(300, 200)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)

        # Заголовок
        title = QLabel(f"{self.car_data['brand']} {self.car_data['model']}")
        title.setFont(QFont("Arial", 12, QFont.Bold))

        # Основная информация
        info = QLabel(f"""
        <b>Год:</b> {self.car_data['year']}<br>
        <b>Цвет:</b> {self.car_data['color']}<br>
        <b>Двигатель:</b> {self.car_data['engine_type']} {self.car_data['engine_volume']}л<br>
        <b>Мощность:</b> {self.car_data['power']} л.с.<br>
        <b>КПП:</b> {self.car_data['transmission']}
        """)

        # Цена
        price = QLabel(f"<b>Цена:</b> {self.car_data['sale_price'] or self.car_data['purchase_price']:,.0f} ₽")
        price.setStyleSheet("color: green; font-weight: bold;")

        # Статус
        status = QLabel(f"<b>Статус:</b> {self.car_data['status']}")

        layout.addWidget(title)
        layout.addWidget(info)
        layout.addWidget(price)
        layout.addWidget(status)

        # Цвет рамки в зависимости от статуса
        self.setStyleSheet("""
            QWidget {
                border: 2px solid #ddd;
                border-radius: 5px;
                background-color: white;
            }
            QWidget:hover {
                border-color: #007bff;
            }
        """)