"""
Модуль для работы с базой данных PostgreSQL
"""
import psycopg2
from psycopg2 import sql
from psycopg2.extras import DictCursor
from typing import List, Dict, Any, Optional, Tuple
import pandas as pd
from datetime import datetime


class Database:
    def __init__(self, host='localhost', database='car_dealership',
                 user='postgres', password='тут ваш пароль', port=5432):
        self.connection_params = {
            'host': host,
            'database': database,
            'user': user,
            'password': password,
            'port': port
        }
        self.conn = None
        self.cursor = None

    def connect(self):
        """Установка соединения с базой данных"""
        try:
            self.conn = psycopg2.connect(**self.connection_params)
            self.cursor = self.conn.cursor(cursor_factory=DictCursor)
            self.conn.autocommit = False
            print("Соединение с БД установлено")
            return True
        except Exception as e:
            print(f"Ошибка подключения к БД: {e}")
            return False

    def disconnect(self):
        """Закрытие соединения с базой данных"""
        if self.cursor:
            self.cursor.close()
        if self.conn:
            self.conn.close()
            print("Соединение с БД закрыто")

    def execute_query(self, query: str, params: tuple = None, fetch: bool = True):
        """Выполнение SQL запроса"""
        try:
            self.cursor.execute(query, params or ())
            if fetch:
                if query.strip().upper().startswith('SELECT'):
                    return self.cursor.fetchall()
                else:
                    self.conn.commit()
                    return self.cursor.rowcount
            self.conn.commit()
        except Exception as e:
            self.conn.rollback()
            print(f"Ошибка выполнения запроса: {e}")
            raise e

    # ============== МЕТОДЫ ДЛЯ АВТОМОБИЛЕЙ ==============

    def get_all_cars(self, status_filter: str = None) -> List[Dict]:
        """Получение списка всех автомобилей"""
        query = """
            SELECT c.*, s.name as supplier_name 
            FROM car_dealership.cars c
            LEFT JOIN car_dealership.suppliers s ON c.supplier_id = s.supplier_id
        """
        if status_filter:
            query += f" WHERE c.status = '{status_filter}'"
        query += " ORDER BY c.brand, c.model, c.year DESC"

        results = self.execute_query(query)
        return [dict(row) for row in results]

    def get_car_by_id(self, car_id: int) -> Optional[Dict]:
        """Получение автомобиля по ID"""
        query = """
            SELECT c.*, s.name as supplier_name 
            FROM car_dealership.cars c
            LEFT JOIN car_dealership.suppliers s ON c.supplier_id = s.supplier_id
            WHERE c.car_id = %s
        """
        result = self.execute_query(query, (car_id,))
        return dict(result[0]) if result else None

    def add_car(self, car_data: Dict) -> int:
        """Добавление нового автомобиля"""
        query = """
            INSERT INTO car_dealership.cars (
                vin, brand, model, year, color, mileage, engine_type, 
                engine_volume, power, transmission, drive_type, trim_level,
                purchase_price, sale_price, arrival_date, status, supplier_id
            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            RETURNING car_id
        """
        result = self.execute_query(query, (
            car_data['vin'], car_data['brand'], car_data['model'],
            car_data['year'], car_data['color'], car_data.get('mileage', 0),
            car_data['engine_type'], car_data['engine_volume'], car_data['power'],
            car_data['transmission'], car_data['drive_type'], car_data['trim_level'],
            car_data['purchase_price'], car_data.get('sale_price'),
            car_data.get('arrival_date', datetime.now().date()),
            car_data.get('status', 'В наличии'), car_data['supplier_id']
        ))
        return result[0]['car_id'] if result else None

    def update_car_status(self, car_id: int, new_status: str):
        """Обновление статуса автомобиля"""
        query = """
            UPDATE car_dealership.cars 
            SET status = %s 
            WHERE car_id = %s
        """
        self.execute_query(query, (new_status, car_id), fetch=False)

    # ============== МЕТОДЫ ДЛЯ КЛИЕНТОВ ==============

    def get_all_clients(self, client_type: str = None) -> List[Dict]:
        """Получение списка всех клиентов"""
        query = "SELECT * FROM car_dealership.clients"
        if client_type:
            query += f" WHERE type = '{client_type}'"
        query += " ORDER BY last_name, first_name"

        results = self.execute_query(query)
        return [dict(row) for row in results]

    def search_clients(self, search_term: str) -> List[Dict]:
        """Поиск клиентов по ФИО или телефону"""
        query = """
            SELECT * FROM car_dealership.clients 
            WHERE last_name ILIKE %s OR first_name ILIKE %s OR phone ILIKE %s
            OR company_name ILIKE %s
            ORDER BY last_name, first_name
        """
        search_pattern = f"%{search_term}%"
        results = self.execute_query(query,
                                     (search_pattern, search_pattern, search_pattern, search_pattern))
        return [dict(row) for row in results]

    # ============== МЕТОДЫ ДЛЯ СДЕЛОК ==============

    def get_all_deals(self, date_from: str = None, date_to: str = None) -> List[Dict]:
        """Получение списка всех сделок"""
        query = """
            SELECT d.*, 
                   c.brand || ' ' || c.model as car_name,
                   cl.last_name || ' ' || cl.first_name as client_name,
                   e.last_name || ' ' || e.first_name as employee_name
            FROM car_dealership.deals d
            JOIN car_dealership.cars c ON d.car_id = c.car_id
            JOIN car_dealership.clients cl ON d.client_id = cl.client_id
            JOIN car_dealership.employees e ON d.employee_id = e.employee_id
        """

        params = []
        if date_from and date_to:
            query += " WHERE d.deal_date BETWEEN %s AND %s"
            params.extend([date_from, date_to])

        query += " ORDER BY d.deal_date DESC"

        results = self.execute_query(query, tuple(params) if params else None)
        return [dict(row) for row in results]

    def create_deal(self, deal_data: Dict) -> int:
        """Создание новой сделки"""
        query = """
            INSERT INTO car_dealership.deals (
                deal_date, car_id, client_id, employee_id, 
                final_price, payment_method, deal_status
            ) VALUES (%s, %s, %s, %s, %s, %s, %s)
            RETURNING deal_id
        """
        result = self.execute_query(query, (
            deal_data['deal_date'], deal_data['car_id'],
            deal_data['client_id'], deal_data['employee_id'],
            deal_data['final_price'], deal_data['payment_method'],
            deal_data.get('deal_status', 'Оформлена')
        ))

        # Обновляем статус автомобиля
        if result:
            self.update_car_status(deal_data['car_id'], 'Продан')

        return result[0]['deal_id'] if result else None

    # ============== МЕТОДЫ ДЛЯ ОТЧЕТОВ ==============

    def get_monthly_sales_report(self, month: int = None, year: int = None) -> pd.DataFrame:
        """Отчет по продажам за месяц"""
        if not month:
            month = datetime.now().month
        if not year:
            year = datetime.now().year

        query = """
            SELECT 
                d.deal_date,
                c.brand || ' ' || c.model as car_name,
                c.vin,
                cl.last_name || ' ' || cl.first_name as client_name,
                e.last_name || ' ' || e.first_name as manager_name,
                d.final_price,
                d.payment_method,
                d.deal_status
            FROM car_dealership.deals d
            JOIN car_dealership.cars c ON d.car_id = c.car_id
            JOIN car_dealership.clients cl ON d.client_id = cl.client_id
            JOIN car_dealership.employees e ON d.employee_id = e.employee_id
            WHERE EXTRACT(YEAR FROM d.deal_date) = %s
                AND EXTRACT(MONTH FROM d.deal_date) = %s
            ORDER BY d.deal_date DESC
        """

        results = self.execute_query(query, (year, month))
        return pd.DataFrame(results)

    def get_profit_report(self) -> pd.DataFrame:
        """Финансовый отчет по прибыли"""
        query = """
            SELECT 
                d.deal_id,
                d.deal_date,
                c.brand || ' ' || c.model as car_name,
                c.vin,
                c.purchase_price,
                d.final_price,
                (d.final_price - c.purchase_price) as profit,
                ROUND(((d.final_price - c.purchase_price) / c.purchase_price * 100), 2) as profit_percent
            FROM car_dealership.deals d
            JOIN car_dealership.cars c ON d.car_id = c.car_id
            WHERE d.deal_status IN ('Оплачена', 'Завершена')
            ORDER BY d.deal_date DESC
        """

        results = self.execute_query(query)
        return pd.DataFrame(results)

    def get_available_cars_report(self) -> pd.DataFrame:
        """Отчет по доступным автомобилям"""
        query = """
            SELECT 
                car_id,
                vin,
                brand,
                model,
                year,
                color,
                mileage,
                engine_type,
                engine_volume,
                power,
                transmission,
                drive_type,
                trim_level,
                sale_price,
                arrival_date
            FROM car_dealership.cars
            WHERE status = 'В наличии'
            ORDER BY brand, model, year DESC
        """

        results = self.execute_query(query)
        return pd.DataFrame(results)

    # ============== ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ ==============

    def get_suppliers(self) -> List[Dict]:
        """Получение списка поставщиков"""
        query = "SELECT * FROM car_dealership.suppliers ORDER BY name"
        results = self.execute_query(query)
        return [dict(row) for row in results]

    def get_employees(self) -> List[Dict]:
        """Получение списка сотрудников"""
        query = """
            SELECT e.*, p.position_name 
            FROM car_dealership.employees e
            JOIN car_dealership.positions p ON e.position_id = p.position_id
            ORDER BY e.last_name, e.first_name
        """
        results = self.execute_query(query)
        return [dict(row) for row in results]

    def get_positions(self) -> List[Dict]:
        """Получение списка должностей"""
        query = "SELECT * FROM car_dealership.positions ORDER BY position_name"
        results = self.execute_query(query)
        return [dict(row) for row in results]

    def get_car_status_types(self) -> List[str]:
        """Получение типов статусов автомобилей"""
        query = "SELECT unnest(enum_range(NULL::car_dealership.car_status_type))"
        results = self.execute_query(query)
        return [row[0] for row in results]

    def get_client_types(self) -> List[str]:
        """Получение типов клиентов"""
        query = "SELECT unnest(enum_range(NULL::car_dealership.client_type))"
        results = self.execute_query(query)
        return [row[0] for row in results]

    def get_payment_methods(self) -> List[str]:
        """Получение способов оплаты"""
        query = "SELECT unnest(enum_range(NULL::car_dealership.payment_method_type))"
        results = self.execute_query(query)
        return [row[0] for row in results]

    def get_statistics(self) -> Dict[str, Any]:
        """Получение статистики по базе данных"""
        stats = {}

        # Количество автомобилей по статусам
        query = """
            SELECT status, COUNT(*) as count 
            FROM car_dealership.cars 
            GROUP BY status
        """
        results = self.execute_query(query)
        stats['cars_by_status'] = {row['status']: row['count'] for row in results}

        # Общее количество клиентов
        query = "SELECT COUNT(*) as count FROM car_dealership.clients"
        results = self.execute_query(query)
        stats['total_clients'] = results[0]['count']

        # Общая сумма продаж
        query = "SELECT SUM(final_price) as total FROM car_dealership.deals"
        results = self.execute_query(query)
        stats['total_sales'] = results[0]['total'] or 0

        # Количество сделок по месяцам
        query = """
            SELECT 
                TO_CHAR(deal_date, 'YYYY-MM') as month,
                COUNT(*) as deals_count,
                SUM(final_price) as month_sales
            FROM car_dealership.deals
            WHERE deal_date >= CURRENT_DATE - INTERVAL '6 months'
            GROUP BY TO_CHAR(deal_date, 'YYYY-MM')
            ORDER BY month DESC
        """
        results = self.execute_query(query)
        stats['monthly_sales'] = [dict(row) for row in results]

        return stats