"""
Главное окно приложения
"""
import sys
import pandas as pd
from PyQt5.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QTabWidget,
    QPushButton, QTableWidget, QTableWidgetItem, QLabel, QMessageBox,
    QComboBox, QLineEdit, QDateEdit, QGroupBox, QFormLayout,
    QSplitter, QStatusBar, QHeaderView, QMenuBar, QMenu, QAction,
    QToolBar, QDialog, QInputDialog, QFileDialog
)
from PyQt5.QtCore import Qt, QDate, pyqtSignal
from PyQt5.QtGui import QIcon, QFont, QPixmap

from database import Database
from dialogs import (
    AddCarDialog, AddClientDialog, AddDealDialog,
    EditCarDialog, EditClientDialog, EditDealDialog,
    ViewDetailsDialog, ReportDialog
)
from widgets import StatisticsWidget, CarCardWidget
from styles import get_stylesheet


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.db = Database()
        self.init_ui()

    def init_ui(self):
        """Инициализация интерфейса"""
        self.setWindowTitle("Автомобильный центр - Система управления")
        self.setGeometry(100, 100, 1400, 800)

        # Установка стилей
        self.setStyleSheet(get_stylesheet())

        # Создание меню
        self.create_menu_bar()

        # Создание панели инструментов
        self.create_toolbar()

        # Создание центрального виджета
        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        # Основной layout
        main_layout = QVBoxLayout(central_widget)

        # Виджет статистики
        self.stats_widget = StatisticsWidget()
        main_layout.addWidget(self.stats_widget)

        # Разделитель
        splitter = QSplitter(Qt.Vertical)

        # Создание вкладок
        self.tab_widget = QTabWidget()

        # Вкладка "Автомобили"
        self.cars_tab = self.create_cars_tab()
        self.tab_widget.addTab(self.cars_tab, "🚗 Автомобили")

        # Вкладка "Клиенты"
        self.clients_tab = self.create_clients_tab()
        self.tab_widget.addTab(self.clients_tab, "👥 Клиенты")

        # Вкладка "Сделки"
        self.deals_tab = self.create_deals_tab()
        self.tab_widget.addTab(self.deals_tab, "📝 Сделки")

        # Вкладка "Отчеты"
        self.reports_tab = self.create_reports_tab()
        self.tab_widget.addTab(self.reports_tab, "📊 Отчеты")

        # Вкладка "Поставщики"
        self.suppliers_tab = self.create_suppliers_tab()
        self.tab_widget.addTab(self.suppliers_tab, "🏢 Поставщики")

        splitter.addWidget(self.tab_widget)

        # Виджет быстрого поиска
        quick_search_widget = self.create_quick_search_widget()
        splitter.addWidget(quick_search_widget)

        splitter.setSizes([600, 200])
        main_layout.addWidget(splitter)

        # Статус бар
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        self.status_bar.showMessage("Готово")

        # Подключение к БД
        self.connect_to_database()

    def create_menu_bar(self):
        """Создание меню"""
        menubar = self.menuBar()

        # Меню Файл
        file_menu = menubar.addMenu('Файл')

        connect_action = QAction('Подключиться к БД', self)
        connect_action.triggered.connect(self.connect_to_database)
        file_menu.addAction(connect_action)

        backup_action = QAction('Создать резервную копию', self)
        backup_action.triggered.connect(self.create_backup)
        file_menu.addAction(backup_action)

        file_menu.addSeparator()

        exit_action = QAction('Выход', self)
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)

        # Меню Справочники
        ref_menu = menubar.addMenu('Справочники')

        employees_action = QAction('Сотрудники', self)
        employees_action.triggered.connect(self.show_employees)
        ref_menu.addAction(employees_action)

        positions_action = QAction('Должности', self)
        positions_action.triggered.connect(self.show_positions)
        ref_menu.addAction(positions_action)

        # Меню Отчеты
        report_menu = menubar.addMenu('Отчеты')

        sales_report_action = QAction('Отчет по продажам', self)
        sales_report_action.triggered.connect(lambda: self.show_report('sales'))
        report_menu.addAction(sales_report_action)

        profit_report_action = QAction('Финансовый отчет', self)
        profit_report_action.triggered.connect(lambda: self.show_report('profit'))
        report_menu.addAction(profit_report_action)

        inventory_report_action = QAction('Остатки на складе', self)
        inventory_report_action.triggered.connect(lambda: self.show_report('inventory'))
        report_menu.addAction(inventory_report_action)

        # Меню Помощь
        help_menu = menubar.addMenu('Помощь')

        about_action = QAction('О программе', self)
        about_action.triggered.connect(self.show_about)
        help_menu.addAction(about_action)

    def create_toolbar(self):
        """Создание панели инструментов"""
        toolbar = QToolBar()
        self.addToolBar(toolbar)

        # Кнопки для автомобилей
        add_car_btn = QPushButton("➕ Добавить авто")
        add_car_btn.clicked.connect(self.add_car)
        toolbar.addWidget(add_car_btn)

        # Кнопки для клиентов
        add_client_btn = QPushButton("➕ Добавить клиента")
        add_client_btn.clicked.connect(self.add_client)
        toolbar.addWidget(add_client_btn)

        # Кнопки для сделок
        add_deal_btn = QPushButton("➕ Новая сделка")
        add_deal_btn.clicked.connect(self.add_deal)
        toolbar.addWidget(add_deal_btn)

        toolbar.addSeparator()

        # Кнопка обновления
        refresh_btn = QPushButton("🔄 Обновить")
        refresh_btn.clicked.connect(self.refresh_all)
        toolbar.addWidget(refresh_btn)

    def create_cars_tab(self):
        """Создание вкладки для автомобилей"""
        tab = QWidget()
        layout = QVBoxLayout(tab)

        # Панель фильтров
        filter_layout = QHBoxLayout()

        self.car_filter_status = QComboBox()
        self.car_filter_status.addItem("Все статусы")
        self.car_filter_status.addItems(self.db.get_car_status_types() if self.db.connect() else [])
        self.car_filter_status.currentTextChanged.connect(self.filter_cars)

        self.car_filter_brand = QLineEdit()
        self.car_filter_brand.setPlaceholderText("Марка...")
        self.car_filter_brand.textChanged.connect(self.filter_cars)

        filter_layout.addWidget(QLabel("Статус:"))
        filter_layout.addWidget(self.car_filter_status)
        filter_layout.addWidget(QLabel("Марка:"))
        filter_layout.addWidget(self.car_filter_brand)
        filter_layout.addStretch()

        # Кнопки управления
        btn_layout = QHBoxLayout()
        self.cars_add_btn = QPushButton("➕ Добавить")
        self.cars_add_btn.clicked.connect(self.add_car)
        self.cars_edit_btn = QPushButton("✏️ Редактировать")
        self.cars_edit_btn.clicked.connect(self.edit_car)
        self.cars_delete_btn = QPushButton("🗑️ Удалить")
        self.cars_delete_btn.clicked.connect(self.delete_car)
        self.cars_view_btn = QPushButton("👁️ Просмотр")
        self.cars_view_btn.clicked.connect(self.view_car_details)

        btn_layout.addWidget(self.cars_add_btn)
        btn_layout.addWidget(self.cars_edit_btn)
        btn_layout.addWidget(self.cars_delete_btn)
        btn_layout.addWidget(self.cars_view_btn)
        btn_layout.addStretch()

        # Таблица автомобилей
        self.cars_table = QTableWidget()
        self.cars_table.setColumnCount(10)
        self.cars_table.setHorizontalHeaderLabels([
            "ID", "Марка", "Модель", "Год", "Цвет",
            "Цена", "Статус", "VIN", "Поставщик", "Дата поступления"
        ])
        self.cars_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.cars_table.doubleClicked.connect(self.view_car_details)

        # Карточный вид для автомобилей
        self.cars_card_view = QWidget()
        self.cars_card_layout = QVBoxLayout(self.cars_card_view)
        self.cars_card_scroll = QWidget()

        layout.addLayout(filter_layout)
        layout.addLayout(btn_layout)
        layout.addWidget(self.cars_table)

        return tab

    def create_clients_tab(self):
        """Создание вкладки для клиентов"""
        tab = QWidget()
        layout = QVBoxLayout(tab)

        # Панель поиска
        search_layout = QHBoxLayout()

        self.client_search_input = QLineEdit()
        self.client_search_input.setPlaceholderText("Поиск по ФИО, телефону или компании...")
        self.client_search_input.textChanged.connect(self.search_clients)

        self.client_filter_type = QComboBox()
        self.client_filter_type.addItem("Все типы")
        self.client_filter_type.addItems(self.db.get_client_types() if self.db.connect() else [])
        self.client_filter_type.currentTextChanged.connect(self.filter_clients)

        search_layout.addWidget(self.client_search_input)
        search_layout.addWidget(QLabel("Тип:"))
        search_layout.addWidget(self.client_filter_type)

        # Кнопки управления
        btn_layout = QHBoxLayout()
        self.clients_add_btn = QPushButton("➕ Добавить")
        self.clients_add_btn.clicked.connect(self.add_client)
        self.clients_edit_btn = QPushButton("✏️ Редактировать")
        self.clients_edit_btn.clicked.connect(self.edit_client)
        self.clients_delete_btn = QPushButton("🗑️ Удалить")
        self.clients_delete_btn.clicked.connect(self.delete_client)

        btn_layout.addWidget(self.clients_add_btn)
        btn_layout.addWidget(self.clients_edit_btn)
        btn_layout.addWidget(self.clients_delete_btn)
        btn_layout.addStretch()

        # Таблица клиентов
        self.clients_table = QTableWidget()
        self.clients_table.setColumnCount(8)
        self.clients_table.setHorizontalHeaderLabels([
            "ID", "Фамилия", "Имя", "Тип", "Телефон", "Email",
            "Компания/Паспорт", "Адрес"
        ])
        self.clients_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)

        layout.addLayout(search_layout)
        layout.addLayout(btn_layout)
        layout.addWidget(self.clients_table)

        return tab

    def create_deals_tab(self):
        """Создание вкладки для сделок"""
        tab = QWidget()
        layout = QVBoxLayout(tab)

        # Фильтры по дате
        date_filter_layout = QHBoxLayout()

        self.deal_date_from = QDateEdit()
        self.deal_date_from.setDate(QDate.currentDate().addMonths(-1))
        self.deal_date_from.setCalendarPopup(True)

        self.deal_date_to = QDateEdit()
        self.deal_date_to.setDate(QDate.currentDate())
        self.deal_date_to.setCalendarPopup(True)

        date_filter_layout.addWidget(QLabel("С:"))
        date_filter_layout.addWidget(self.deal_date_from)
        date_filter_layout.addWidget(QLabel("По:"))
        date_filter_layout.addWidget(self.deal_date_to)

        filter_btn = QPushButton("Фильтровать")
        filter_btn.clicked.connect(self.filter_deals)
        date_filter_layout.addWidget(filter_btn)

        reset_btn = QPushButton("Сбросить")
        reset_btn.clicked.connect(self.reset_deals_filter)
        date_filter_layout.addWidget(reset_btn)

        date_filter_layout.addStretch()

        # Кнопки управления
        btn_layout = QHBoxLayout()
        self.deals_add_btn = QPushButton("➕ Новая сделка")
        self.deals_add_btn.clicked.connect(self.add_deal)
        self.deals_edit_btn = QPushButton("✏️ Редактировать")
        self.deals_edit_btn.clicked.connect(self.edit_deal)
        self.deals_view_btn = QPushButton("👁️ Подробнее")
        self.deals_view_btn.clicked.connect(self.view_deal_details)

        btn_layout.addWidget(self.deals_add_btn)
        btn_layout.addWidget(self.deals_edit_btn)
        btn_layout.addWidget(self.deals_view_btn)
        btn_layout.addStretch()

        # Таблица сделок
        self.deals_table = QTableWidget()
        self.deals_table.setColumnCount(9)
        self.deals_table.setHorizontalHeaderLabels([
            "ID", "Дата", "Автомобиль", "Клиент", "Менеджер",
            "Сумма", "Способ оплаты", "Статус", "Прибыль"
        ])
        self.deals_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)

        layout.addLayout(date_filter_layout)
        layout.addLayout(btn_layout)
        layout.addWidget(self.deals_table)

        return tab

    def create_reports_tab(self):
        """Создание вкладки для отчетов"""
        tab = QWidget()
        layout = QVBoxLayout(tab)

        # Кнопки отчетов
        reports_group = QGroupBox("Отчеты")
        reports_layout = QVBoxLayout()

        self.report_sales_btn = QPushButton("📈 Отчет по продажам")
        self.report_sales_btn.clicked.connect(lambda: self.generate_report('sales'))

        self.report_profit_btn = QPushButton("💰 Финансовый отчет")
        self.report_profit_btn.clicked.connect(lambda: self.generate_report('profit'))

        self.report_inventory_btn = QPushButton("📦 Остатки на складе")
        self.report_inventory_btn.clicked.connect(lambda: self.generate_report('inventory'))

        self.report_clients_btn = QPushButton("👥 Отчет по клиентам")
        self.report_clients_btn.clicked.connect(lambda: self.generate_report('clients'))

        self.report_employees_btn = QPushButton("👨‍💼 Отчет по менеджерам")
        self.report_employees_btn.clicked.connect(lambda: self.generate_report('employees'))

        reports_layout.addWidget(self.report_sales_btn)
        reports_layout.addWidget(self.report_profit_btn)
        reports_layout.addWidget(self.report_inventory_btn)
        reports_layout.addWidget(self.report_clients_btn)
        reports_layout.addWidget(self.report_employees_btn)

        reports_group.setLayout(reports_layout)

        # Статистика
        stats_group = QGroupBox("Статистика")
        stats_layout = QVBoxLayout()

        self.stats_label = QLabel()
        self.stats_label.setAlignment(Qt.AlignLeft)
        self.stats_label.setTextFormat(Qt.RichText)

        stats_layout.addWidget(self.stats_label)
        stats_group.setLayout(stats_layout)

        layout.addWidget(reports_group)
        layout.addWidget(stats_group)
        layout.addStretch()

        return tab

    def create_suppliers_tab(self):
        """Создание вкладки для поставщиков"""
        tab = QWidget()
        layout = QVBoxLayout(tab)

        # Таблица поставщиков
        self.suppliers_table = QTableWidget()
        self.suppliers_table.setColumnCount(6)
        self.suppliers_table.setHorizontalHeaderLabels([
            "ID", "Название", "ИНН", "Юридический адрес",
            "Контактное лицо", "Телефон"
        ])
        self.suppliers_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)

        # Кнопки управления
        btn_layout = QHBoxLayout()
        self.suppliers_add_btn = QPushButton("➕ Добавить поставщика")
        self.suppliers_add_btn.clicked.connect(self.add_supplier)

        btn_layout.addWidget(self.suppliers_add_btn)
        btn_layout.addStretch()

        layout.addLayout(btn_layout)
        layout.addWidget(self.suppliers_table)

        return tab

    def create_quick_search_widget(self):
        """Создание виджета быстрого поиска"""
        widget = QWidget()
        layout = QVBoxLayout(widget)

        group = QGroupBox("🔍 Быстрый поиск")
        group_layout = QVBoxLayout()

        self.quick_search_input = QLineEdit()
        self.quick_search_input.setPlaceholderText("Введите VIN, телефон или ФИО...")

        search_btn = QPushButton("Найти")
        search_btn.clicked.connect(self.quick_search)

        self.quick_search_result = QLabel()
        self.quick_search_result.setWordWrap(True)

        group_layout.addWidget(self.quick_search_input)
        group_layout.addWidget(search_btn)
        group_layout.addWidget(self.quick_search_result)

        group.setLayout(group_layout)
        layout.addWidget(group)

        return widget

    # ============== МЕТОДЫ РАБОТЫ С ДАННЫМИ ==============

    def connect_to_database(self):
        """Подключение к базе данных"""
        try:
            if self.db.connect():
                self.status_bar.showMessage("Подключено к базе данных")
                self.load_all_data()
                self.update_statistics()
                return True
            else:
                QMessageBox.critical(self, "Ошибка",
                                     "Не удалось подключиться к базе данных")
                return False
        except Exception as e:
            QMessageBox.critical(self, "Ошибка",
                                 f"Ошибка подключения к БД: {str(e)}")
            return False

    def load_all_data(self):
        """Загрузка всех данных из БД"""
        self.load_cars()
        self.load_clients()
        self.load_deals()
        self.load_suppliers()

    def load_cars(self):
        """Загрузка автомобилей"""
        try:
            cars = self.db.get_all_cars()
            self.cars_table.setRowCount(len(cars))

            for row, car in enumerate(cars):
                self.cars_table.setItem(row, 0, QTableWidgetItem(str(car['car_id'])))
                self.cars_table.setItem(row, 1, QTableWidgetItem(car['brand']))
                self.cars_table.setItem(row, 2, QTableWidgetItem(car['model']))
                self.cars_table.setItem(row, 3, QTableWidgetItem(str(car['year'])))
                self.cars_table.setItem(row, 4, QTableWidgetItem(car['color'] or ''))

                price = car['sale_price'] or car['purchase_price']
                self.cars_table.setItem(row, 5, QTableWidgetItem(f"{price:,.0f} ₽"))

                status_item = QTableWidgetItem(car['status'])
                # Раскрашиваем статусы
                if car['status'] == 'Продан':
                    status_item.setBackground(Qt.green)
                elif car['status'] == 'Забронирован':
                    status_item.setBackground(Qt.yellow)
                elif car['status'] == 'На сервисе':
                    status_item.setBackground(Qt.red)

                self.cars_table.setItem(row, 6, status_item)
                self.cars_table.setItem(row, 7, QTableWidgetItem(car['vin']))
                self.cars_table.setItem(row, 8, QTableWidgetItem(car.get('supplier_name', '')))
                self.cars_table.setItem(row, 9, QTableWidgetItem(str(car['arrival_date'])))

        except Exception as e:
            print(f"Ошибка загрузки автомобилей: {e}")

    def filter_cars(self):
        """Фильтрация автомобилей"""
        status_filter = None
        if self.car_filter_status.currentText() != "Все статусы":
            status_filter = self.car_filter_status.currentText()

        brand_filter = self.car_filter_brand.text().strip()

        try:
            cars = self.db.get_all_cars(status_filter)

            # Дополнительная фильтрация по марке
            if brand_filter:
                cars = [car for car in cars if brand_filter.lower() in car['brand'].lower()]

            self.cars_table.setRowCount(len(cars))

            for row, car in enumerate(cars):
                self.cars_table.setItem(row, 0, QTableWidgetItem(str(car['car_id'])))
                self.cars_table.setItem(row, 1, QTableWidgetItem(car['brand']))
                self.cars_table.setItem(row, 2, QTableWidgetItem(car['model']))
                self.cars_table.setItem(row, 3, QTableWidgetItem(str(car['year'])))
                self.cars_table.setItem(row, 4, QTableWidgetItem(car['color'] or ''))

                price = car['sale_price'] or car['purchase_price']
                self.cars_table.setItem(row, 5, QTableWidgetItem(f"{price:,.0f} ₽"))

                status_item = QTableWidgetItem(car['status'])
                self.cars_table.setItem(row, 6, status_item)
                self.cars_table.setItem(row, 7, QTableWidgetItem(car['vin']))
                self.cars_table.setItem(row, 8, QTableWidgetItem(car.get('supplier_name', '')))
                self.cars_table.setItem(row, 9, QTableWidgetItem(str(car['arrival_date'])))

        except Exception as e:
            print(f"Ошибка фильтрации автомобилей: {e}")

    def load_clients(self):
        """Загрузка клиентов"""
        try:
            clients = self.db.get_all_clients()
            self.clients_table.setRowCount(len(clients))

            for row, client in enumerate(clients):
                self.clients_table.setItem(row, 0, QTableWidgetItem(str(client['client_id'])))
                self.clients_table.setItem(row, 1, QTableWidgetItem(client['last_name'] or ''))
                self.clients_table.setItem(row, 2, QTableWidgetItem(client['first_name'] or ''))
                self.clients_table.setItem(row, 3, QTableWidgetItem(client['type']))
                self.clients_table.setItem(row, 4, QTableWidgetItem(client['phone']))
                self.clients_table.setItem(row, 5, QTableWidgetItem(client['email'] or ''))

                # Отображаем либо компанию, либо паспорт
                if client['type'] == 'Юридическое лицо':
                    self.clients_table.setItem(row, 6, QTableWidgetItem(client['company_name']))
                else:
                    self.clients_table.setItem(row, 6, QTableWidgetItem(client['passport_number'] or ''))

                self.clients_table.setItem(row, 7, QTableWidgetItem(client['address'] or ''))

        except Exception as e:
            print(f"Ошибка загрузки клиентов: {e}")

    def search_clients(self):
        """Поиск клиентов"""
        search_term = self.client_search_input.text().strip()

        if not search_term:
            self.load_clients()
            return

        try:
            clients = self.db.search_clients(search_term)
            self.clients_table.setRowCount(len(clients))

            for row, client in enumerate(clients):
                self.clients_table.setItem(row, 0, QTableWidgetItem(str(client['client_id'])))
                self.clients_table.setItem(row, 1, QTableWidgetItem(client['last_name'] or ''))
                self.clients_table.setItem(row, 2, QTableWidgetItem(client['first_name'] or ''))
                self.clients_table.setItem(row, 3, QTableWidgetItem(client['type']))
                self.clients_table.setItem(row, 4, QTableWidgetItem(client['phone']))
                self.clients_table.setItem(row, 5, QTableWidgetItem(client['email'] or ''))

                if client['type'] == 'Юридическое лицо':
                    self.clients_table.setItem(row, 6, QTableWidgetItem(client['company_name']))
                else:
                    self.clients_table.setItem(row, 6, QTableWidgetItem(client['passport_number'] or ''))

                self.clients_table.setItem(row, 7, QTableWidgetItem(client['address'] or ''))

        except Exception as e:
            print(f"Ошибка поиска клиентов: {e}")

    def filter_clients(self):
        """Фильтрация клиентов по типу"""
        client_type = None
        if self.client_filter_type.currentText() != "Все типы":
            client_type = self.client_filter_type.currentText()

        try:
            clients = self.db.get_all_clients(client_type)
            self.clients_table.setRowCount(len(clients))

            for row, client in enumerate(clients):
                self.clients_table.setItem(row, 0, QTableWidgetItem(str(client['client_id'])))
                self.clients_table.setItem(row, 1, QTableWidgetItem(client['last_name'] or ''))
                self.clients_table.setItem(row, 2, QTableWidgetItem(client['first_name'] or ''))
                self.clients_table.setItem(row, 3, QTableWidgetItem(client['type']))
                self.clients_table.setItem(row, 4, QTableWidgetItem(client['phone']))
                self.clients_table.setItem(row, 5, QTableWidgetItem(client['email'] or ''))

                if client['type'] == 'Юридическое лицо':
                    self.clients_table.setItem(row, 6, QTableWidgetItem(client['company_name']))
                else:
                    self.clients_table.setItem(row, 6, QTableWidgetItem(client['passport_number'] or ''))

                self.clients_table.setItem(row, 7, QTableWidgetItem(client['address'] or ''))

        except Exception as e:
            print(f"Ошибка фильтрации клиентов: {e}")

    def load_deals(self):
        """Загрузка сделок"""
        try:
            deals = self.db.get_all_deals()
            self.deals_table.setRowCount(len(deals))

            total_profit = 0

            for row, deal in enumerate(deals):
                self.deals_table.setItem(row, 0, QTableWidgetItem(str(deal['deal_id'])))
                self.deals_table.setItem(row, 1, QTableWidgetItem(str(deal['deal_date'])))
                self.deals_table.setItem(row, 2, QTableWidgetItem(deal['car_name']))
                self.deals_table.setItem(row, 3, QTableWidgetItem(deal['client_name']))
                self.deals_table.setItem(row, 4, QTableWidgetItem(deal['employee_name']))
                self.deals_table.setItem(row, 5, QTableWidgetItem(f"{deal['final_price']:,.0f} ₽"))
                self.deals_table.setItem(row, 6, QTableWidgetItem(deal['payment_method']))

                status_item = QTableWidgetItem(deal['deal_status'])
                if deal['deal_status'] == 'Завершена':
                    status_item.setBackground(Qt.green)
                elif deal['deal_status'] == 'Оформлена':
                    status_item.setBackground(Qt.yellow)

                self.deals_table.setItem(row, 7, status_item)

                # Расчет прибыли (нужно получить цену закупки)
                try:
                    car = self.db.get_car_by_id(deal['car_id'])
                    if car:
                        profit = deal['final_price'] - car['purchase_price']
                        total_profit += profit
                        self.deals_table.setItem(row, 8, QTableWidgetItem(f"{profit:,.0f} ₽"))
                except:
                    self.deals_table.setItem(row, 8, QTableWidgetItem("N/A"))

        except Exception as e:
            print(f"Ошибка загрузки сделок: {e}")

    def filter_deals(self):
        """Фильтрация сделок по дате"""
        date_from = self.deal_date_from.date().toString("yyyy-MM-dd")
        date_to = self.deal_date_to.date().toString("yyyy-MM-dd")

        try:
            deals = self.db.get_all_deals(date_from, date_to)
            self.deals_table.setRowCount(len(deals))

            for row, deal in enumerate(deals):
                self.deals_table.setItem(row, 0, QTableWidgetItem(str(deal['deal_id'])))
                self.deals_table.setItem(row, 1, QTableWidgetItem(str(deal['deal_date'])))
                self.deals_table.setItem(row, 2, QTableWidgetItem(deal['car_name']))
                self.deals_table.setItem(row, 3, QTableWidgetItem(deal['client_name']))
                self.deals_table.setItem(row, 4, QTableWidgetItem(deal['employee_name']))
                self.deals_table.setItem(row, 5, QTableWidgetItem(f"{deal['final_price']:,.0f} ₽"))
                self.deals_table.setItem(row, 6, QTableWidgetItem(deal['payment_method']))
                self.deals_table.setItem(row, 7, QTableWidgetItem(deal['deal_status']))

        except Exception as e:
            print(f"Ошибка фильтрации сделок: {e}")

    def reset_deals_filter(self):
        """Сброс фильтра сделок"""
        self.deal_date_from.setDate(QDate.currentDate().addMonths(-1))
        self.deal_date_to.setDate(QDate.currentDate())
        self.load_deals()

    def load_suppliers(self):
        """Загрузка поставщиков"""
        try:
            suppliers = self.db.get_suppliers()
            self.suppliers_table.setRowCount(len(suppliers))

            for row, supplier in enumerate(suppliers):
                self.suppliers_table.setItem(row, 0, QTableWidgetItem(str(supplier['supplier_id'])))
                self.suppliers_table.setItem(row, 1, QTableWidgetItem(supplier['name']))
                self.suppliers_table.setItem(row, 2, QTableWidgetItem(supplier['inn']))
                self.suppliers_table.setItem(row, 3, QTableWidgetItem(supplier['legal_address']))
                self.suppliers_table.setItem(row, 4, QTableWidgetItem(supplier['contact_person'] or ''))
                self.suppliers_table.setItem(row, 5, QTableWidgetItem(supplier['phone']))

        except Exception as e:
            print(f"Ошибка загрузки поставщиков: {e}")

    # ============== МЕТОДЫ ДЛЯ РАБОТЫ С АВТОМОБИЛЯМИ ==============

    def add_car(self):
        """Добавление нового автомобиля"""
        dialog = AddCarDialog(self.db, self)
        if dialog.exec_():
            self.load_cars()
            self.update_statistics()
            self.status_bar.showMessage("Автомобиль добавлен")

    def edit_car(self):
        """Редактирование выбранного автомобиля"""
        selected_row = self.cars_table.currentRow()
        if selected_row < 0:
            QMessageBox.warning(self, "Предупреждение", "Выберите автомобиль для редактирования")
            return

        car_id = int(self.cars_table.item(selected_row, 0).text())

        dialog = EditCarDialog(self.db, car_id, self)
        if dialog.exec_():
            self.load_cars()
            self.status_bar.showMessage("Автомобиль обновлен")

    def delete_car(self):
        """Удаление выбранного автомобиля"""
        selected_row = self.cars_table.currentRow()
        if selected_row < 0:
            QMessageBox.warning(self, "Предупреждение", "Выберите автомобиль для удаления")
            return

        car_id = int(self.cars_table.item(selected_row, 0).text())
        car_info = f"{self.cars_table.item(selected_row, 1).text()} {self.cars_table.item(selected_row, 2).text()}"

        reply = QMessageBox.question(
            self, 'Подтверждение удаления',
            f'Вы уверены, что хотите удалить автомобиль "{car_info}"?',
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )

        if reply == QMessageBox.Yes:
            try:
                query = "DELETE FROM car_dealership.cars WHERE car_id = %s"
                self.db.execute_query(query, (car_id,), fetch=False)
                self.load_cars()
                self.update_statistics()
                self.status_bar.showMessage("Автомобиль удален")
            except Exception as e:
                QMessageBox.critical(self, "Ошибка",
                                     f"Не удалось удалить автомобиль: {str(e)}")

    def view_car_details(self):
        """Просмотр подробной информации об автомобиле"""
        selected_row = self.cars_table.currentRow()
        if selected_row < 0:
            QMessageBox.warning(self, "Предупреждение", "Выберите автомобиль для просмотра")
            return

        car_id = int(self.cars_table.item(selected_row, 0).text())

        dialog = ViewDetailsDialog(self.db, 'car', car_id, self)
        dialog.exec_()

    # ============== МЕТОДЫ ДЛЯ РАБОТЫ С КЛИЕНТАМИ ==============

    def add_client(self):
        """Добавление нового клиента"""
        dialog = AddClientDialog(self.db, self)
        if dialog.exec_():
            self.load_clients()
            self.update_statistics()
            self.status_bar.showMessage("Клиент добавлен")

    def edit_client(self):
        """Редактирование выбранного клиента"""
        selected_row = self.clients_table.currentRow()
        if selected_row < 0:
            QMessageBox.warning(self, "Предупреждение", "Выберите клиента для редактирования")
            return

        client_id = int(self.clients_table.item(selected_row, 0).text())

        dialog = EditClientDialog(self.db, client_id, self)
        if dialog.exec_():
            self.load_clients()
            self.status_bar.showMessage("Клиент обновлен")

    def delete_client(self):
        """Удаление выбранного клиента"""
        selected_row = self.clients_table.currentRow()
        if selected_row < 0:
            QMessageBox.warning(self, "Предупреждение", "Выберите клиента для удаления")
            return

        client_id = int(self.clients_table.item(selected_row, 0).text())
        client_name = f"{self.clients_table.item(selected_row, 1).text()} {self.clients_table.item(selected_row, 2).text()}"

        # Проверка, есть ли у клиента сделки
        try:
            query = "SELECT COUNT(*) FROM car_dealership.deals WHERE client_id = %s"
            result = self.db.execute_query(query, (client_id,))
            deal_count = result[0][0]

            if deal_count > 0:
                QMessageBox.warning(self, "Предупреждение",
                                    f"Невозможно удалить клиента. У него есть {deal_count} сделок.")
                return
        except:
            pass

        reply = QMessageBox.question(
            self, 'Подтверждение удаления',
            f'Вы уверены, что хотите удалить клиента "{client_name}"?',
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )

        if reply == QMessageBox.Yes:
            try:
                query = "DELETE FROM car_dealership.clients WHERE client_id = %s"
                self.db.execute_query(query, (client_id,), fetch=False)
                self.load_clients()
                self.update_statistics()
                self.status_bar.showMessage("Клиент удален")
            except Exception as e:
                QMessageBox.critical(self, "Ошибка",
                                     f"Не удалось удалить клиента: {str(e)}")

    # ============== МЕТОДЫ ДЛЯ РАБОТЫ СО СДЕЛКАМИ ==============

    def add_deal(self):
        """Добавление новой сделки"""
        dialog = AddDealDialog(self.db, self)
        if dialog.exec_():
            self.load_deals()
            self.load_cars()  # Обновляем статус автомобилей
            self.update_statistics()
            self.status_bar.showMessage("Сделка добавлена")

    def edit_deal(self):
        """Редактирование выбранной сделки"""
        selected_row = self.deals_table.currentRow()
        if selected_row < 0:
            QMessageBox.warning(self, "Предупреждение", "Выберите сделку для редактирования")
            return

        deal_id = int(self.deals_table.item(selected_row, 0).text())

        dialog = EditDealDialog(self.db, deal_id, self)
        if dialog.exec_():
            self.load_deals()
            self.status_bar.showMessage("Сделка обновлена")

    def view_deal_details(self):
        """Просмотр подробной информации о сделке"""
        selected_row = self.deals_table.currentRow()
        if selected_row < 0:
            QMessageBox.warning(self, "Предупреждение", "Выберите сделку для просмотра")
            return

        deal_id = int(self.deals_table.item(selected_row, 0).text())

        dialog = ViewDetailsDialog(self.db, 'deal', deal_id, self)
        dialog.exec_()

    # ============== МЕТОДЫ ДЛЯ РАБОТЫ С ПОСТАВЩИКАМИ ==============

    def add_supplier(self):
        """Добавление нового поставщика"""
        name, ok = QInputDialog.getText(self, 'Добавить поставщика', 'Название:')
        if ok and name:
            inn, ok = QInputDialog.getText(self, 'Добавить поставщика', 'ИНН:')
            if ok and inn:
                address, ok = QInputDialog.getText(self, 'Добавить поставщика', 'Юридический адрес:')
                if ok and address:
                    phone, ok = QInputDialog.getText(self, 'Добавить поставщика', 'Телефон:')
                    if ok and phone:
                        try:
                            query = """
                                INSERT INTO car_dealership.suppliers 
                                (name, inn, legal_address, phone) 
                                VALUES (%s, %s, %s, %s)
                            """
                            self.db.execute_query(query, (name, inn, address, phone), fetch=False)
                            self.load_suppliers()
                            self.status_bar.showMessage("Поставщик добавлен")
                        except Exception as e:
                            QMessageBox.critical(self, "Ошибка",
                                                 f"Не удалось добавить поставщика: {str(e)}")

    # ============== МЕТОДЫ ДЛЯ ОТЧЕТОВ ==============

    def generate_report(self, report_type):
        """Генерация отчета"""
        try:
            if report_type == 'sales':
                df = self.db.get_monthly_sales_report()
                title = "Отчет по продажам"
            elif report_type == 'profit':
                df = self.db.get_profit_report()
                title = "Финансовый отчет"
            elif report_type == 'inventory':
                df = self.db.get_available_cars_report()
                title = "Остатки на складе"
            else:
                QMessageBox.information(self, "Информация", "Данный отчет в разработке")
                return

            dialog = ReportDialog(df, title, self)
            dialog.exec_()

        except Exception as e:
            QMessageBox.critical(self, "Ошибка",
                                 f"Ошибка генерации отчета: {str(e)}")

    def show_report(self, report_type):
        """Показать отчет (для меню)"""
        self.tab_widget.setCurrentIndex(3)  # Переход на вкладку отчетов
        self.generate_report(report_type)

    # ============== ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ ==============

    def update_statistics(self):
        """Обновление статистики"""
        try:
            stats = self.db.get_statistics()

            # Обновляем виджет статистики
            self.stats_widget.update_stats(stats)

            # Обновляем статистику на вкладке отчетов
            stats_text = f"""
            <h3>📊 Общая статистика</h3>
            <b>Всего клиентов:</b> {stats.get('total_clients', 0)}<br>
            <b>Общая сумма продаж:</b> {stats.get('total_sales', 0):,.0f} ₽<br>
            <br>
            <b>Автомобили по статусам:</b><br>
            """

            for status, count in stats.get('cars_by_status', {}).items():
                stats_text += f"  • {status}: {count}<br>"

            self.stats_label.setText(stats_text)

        except Exception as e:
            print(f"Ошибка обновления статистики: {e}")

    def quick_search(self):
        """Быстрый поиск по базе данных"""
        search_term = self.quick_search_input.text().strip()

        if not search_term:
            self.quick_search_result.setText("Введите поисковый запрос")
            return

        try:
            # Поиск автомобиля по VIN
            query = "SELECT * FROM car_dealership.cars WHERE vin ILIKE %s"
            cars = self.db.execute_query(query, (f"%{search_term}%",))

            # Поиск клиента по телефону
            query = "SELECT * FROM car_dealership.clients WHERE phone ILIKE %s"
            clients = self.db.execute_query(query, (f"%{search_term}%",))

            # Поиск клиента по ФИО
            query = """
                SELECT * FROM car_dealership.clients 
                WHERE last_name ILIKE %s OR first_name ILIKE %s
            """
            clients_by_name = self.db.execute_query(query,
                                                    (f"%{search_term}%", f"%{search_term}%"))

            result_text = f"<b>Результаты поиска для '{search_term}':</b><br><br>"

            if cars:
                result_text += f"<b>Автомобили:</b> найдено {len(cars)}<br>"
                for car in cars[:3]:  # Показываем первые 3
                    result_text += f"  • {car['brand']} {car['model']} ({car['vin']})<br>"
                if len(cars) > 3:
                    result_text += f"  ... и еще {len(cars) - 3}<br>"
                result_text += "<br>"

            if clients or clients_by_name:
                all_clients = set()
                if clients:
                    all_clients.update([tuple(c.items()) for c in clients])
                if clients_by_name:
                    all_clients.update([tuple(c.items()) for c in clients_by_name])

                result_text += f"<b>Клиенты:</b> найдено {len(all_clients)}<br>"
                for client in list(all_clients)[:3]:
                    client_dict = dict(client)
                    name = f"{client_dict.get('last_name', '')} {client_dict.get('first_name', '')}".strip()
                    if not name:
                        name = client_dict.get('company_name', '')
                    result_text += f"  • {name} ({client_dict.get('phone', '')})<br>"
                if len(all_clients) > 3:
                    result_text += f"  ... и еще {len(all_clients) - 3}<br>"

            if not cars and not clients and not clients_by_name:
                result_text = f"По запросу '{search_term}' ничего не найдено"

            self.quick_search_result.setText(result_text)

        except Exception as e:
            self.quick_search_result.setText(f"Ошибка поиска: {str(e)}")

    def refresh_all(self):
        """Обновление всех данных"""
        self.status_bar.showMessage("Обновление данных...")
        self.load_all_data()
        self.update_statistics()
        self.status_bar.showMessage("Данные обновлены")

    def create_backup(self):
        """Создание резервной копии базы данных"""
        file_path, _ = QFileDialog.getSaveFileName(
            self, "Сохранить резервную копию",
            f"car_dealership_backup_{QDate.currentDate().toString('yyyy-MM-dd')}.sql",
            "SQL files (*.sql);;All files (*.*)"
        )

        if file_path:
            try:
                # Простой экспорт через pg_dump (нужен доступ к командной строке)
                import subprocess
                import os

                cmd = [
                    'pg_dump',
                    '-U', self.db.connection_params['user'],
                    '-h', self.db.connection_params['host'],
                    '-p', str(self.db.connection_params['port']),
                    '-d', self.db.connection_params['database'],
                    '-f', file_path
                ]

                env = os.environ.copy()
                env['PGPASSWORD'] = self.db.connection_params['password']

                result = subprocess.run(cmd, env=env, capture_output=True, text=True)

                if result.returncode == 0:
                    QMessageBox.information(self, "Успех",
                                            f"Резервная копия создана: {file_path}")
                else:
                    QMessageBox.critical(self, "Ошибка",
                                         f"Ошибка создания резервной копии:\n{result.stderr}")

            except Exception as e:
                QMessageBox.critical(self, "Ошибка",
                                     f"Ошибка создания резервной копии: {str(e)}")

    def show_employees(self):
        """Показать список сотрудников"""
        try:
            employees = self.db.get_employees()

            dialog = QDialog(self)
            dialog.setWindowTitle("Сотрудники")
            dialog.setGeometry(200, 200, 800, 400)

            layout = QVBoxLayout(dialog)

            table = QTableWidget()
            table.setColumnCount(8)
            table.setHorizontalHeaderLabels([
                "ID", "Фамилия", "Имя", "Отчество", "Должность",
                "Телефон", "Email", "Логин"
            ])
            table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)

            table.setRowCount(len(employees))
            for row, emp in enumerate(employees):
                table.setItem(row, 0, QTableWidgetItem(str(emp['employee_id'])))
                table.setItem(row, 1, QTableWidgetItem(emp['last_name']))
                table.setItem(row, 2, QTableWidgetItem(emp['first_name']))
                table.setItem(row, 3, QTableWidgetItem(emp['middle_name'] or ''))
                table.setItem(row, 4, QTableWidgetItem(emp['position_name']))
                table.setItem(row, 5, QTableWidgetItem(emp['phone']))
                table.setItem(row, 6, QTableWidgetItem(emp['email'] or ''))
                table.setItem(row, 7, QTableWidgetItem(emp['login']))

            layout.addWidget(table)

            close_btn = QPushButton("Закрыть")
            close_btn.clicked.connect(dialog.close)
            layout.addWidget(close_btn)

            dialog.exec_()

        except Exception as e:
            QMessageBox.critical(self, "Ошибка",
                                 f"Ошибка загрузки сотрудников: {str(e)}")

    def show_positions(self):
        """Показать список должностей"""
        try:
            positions = self.db.get_positions()

            dialog = QDialog(self)
            dialog.setWindowTitle("Должности")
            dialog.setGeometry(200, 200, 400, 300)

            layout = QVBoxLayout(dialog)

            table = QTableWidget()
            table.setColumnCount(2)
            table.setHorizontalHeaderLabels(["ID", "Название должности"])
            table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)

            table.setRowCount(len(positions))
            for row, pos in enumerate(positions):
                table.setItem(row, 0, QTableWidgetItem(str(pos['position_id'])))
                table.setItem(row, 1, QTableWidgetItem(pos['position_name']))

            layout.addWidget(table)

            close_btn = QPushButton("Закрыть")
            close_btn.clicked.connect(dialog.close)
            layout.addWidget(close_btn)

            dialog.exec_()

        except Exception as e:
            QMessageBox.critical(self, "Ошибка",
                                 f"Ошибка загрузки должностей: {str(e)}")

    def show_about(self):
        """Показать информацию о программе"""
        about_text = """
        <h2>Автомобильный центр - Система управления</h2>
        <p>Версия 1.0</p>
        <p>Разработано для курсовой работы по дисциплине 
        "Технология разработки и защиты баз данных"</p>
        <p><b>Студент:</b> Черных Эльвира Николаевна</p>
        <p><b>Группа:</b> 414</p>
        <p><b>Специальность:</b> 09.02.07 "Информационные системы и программирование"</p>
        <p><b>ГПОУ «Сыктывкарский политехнический техникум»</b></p>
        <p>2025 г.</p>
        """

        QMessageBox.about(self, "О программе", about_text)

    def closeEvent(self, event):
        """Обработка закрытия приложения"""
        self.db.disconnect()
        event.accept()